"""
GrowDoc 持久化机制实现
"""
import sqlite3
import numpy as np
import json
import logging
import time
from typing import Optional, Dict, Any, List
from .document import Document
from .document_node import DocumentNode
from .coordinate_system import CoordinateSystem


class PersistenceManager:
    """持久化管理器"""
    
    def __init__(self, db_path: str = "growdoc.db"):
        """
        初始化持久化管理器
        
        Args:
            db_path: 数据库文件路径
        """
        self.db_path = db_path
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.logger = logging.getLogger(__name__)
        self._init_db()
    
    def _init_db(self):
        """初始化数据库表结构"""
        cursor = self.conn.cursor()
        
        try:
            # 文档表
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS documents (
                doc_id INTEGER PRIMARY KEY,
                title TEXT NOT NULL,
                created_at REAL NOT NULL,
                updated_at REAL NOT NULL,
                metadata TEXT DEFAULT '{}'
            )
            ''')
            
            # 节点表
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS nodes (
                node_id INTEGER PRIMARY KEY,
                doc_id INTEGER NOT NULL,
                parent_id INTEGER,
                content TEXT NOT NULL,
                level INTEGER NOT NULL,
                vector BLOB,
                metadata TEXT DEFAULT '{}',
                created_at REAL NOT NULL,
                updated_at REAL NOT NULL,
                FOREIGN KEY (doc_id) REFERENCES documents(doc_id),
                FOREIGN KEY (parent_id) REFERENCES nodes(node_id)
            )
            ''')
            
            # 坐标表（用于快速查询和验证）
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS coordinates (
                node_id INTEGER PRIMARY KEY,
                doc_id INTEGER NOT NULL,
                coordinate INTEGER NOT NULL,
                level_count INTEGER NOT NULL,
                levels TEXT NOT NULL,
                FOREIGN KEY (node_id) REFERENCES nodes(node_id),
                FOREIGN KEY (doc_id) REFERENCES documents(doc_id)
            )
            ''')
            
            # 创建索引
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_nodes_doc_id ON nodes(doc_id)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_nodes_parent_id ON nodes(parent_id)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_nodes_level ON nodes(level)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_coordinates_doc_id ON coordinates(doc_id)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_coordinates_coordinate ON coordinates(coordinate)')
            
            # 版本信息表
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS schema_version (
                version INTEGER PRIMARY KEY,
                created_at REAL NOT NULL
            )
            ''')
            
            # 插入当前版本
            cursor.execute('INSERT OR IGNORE INTO schema_version (version, created_at) VALUES (1, ?)', 
                          (time.time(),))
            
            self.conn.commit()
            self.logger.info("Database initialized successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize database: {str(e)}")
            self.conn.rollback()
            raise
    
    def save_document(self, document: Document) -> bool:
        """
        保存文档到数据库
        
        Args:
            document: 要保存的文档
            
        Returns:
            True如果保存成功，False否则
        """
        cursor = self.conn.cursor()
        
        try:
            # 开始事务
            cursor.execute('BEGIN TRANSACTION')
            
            # 保存文档元数据
            cursor.execute('''
            INSERT OR REPLACE INTO documents (doc_id, title, created_at, updated_at, metadata)
            VALUES (?, ?, ?, ?, ?)
            ''', (
                document.doc_id,
                document.title,
                document.created_at,
                document.updated_at,
                json.dumps(document.metadata, ensure_ascii=False)
            ))
            
            # 删除现有的节点和坐标数据
            cursor.execute('DELETE FROM coordinates WHERE doc_id = ?', (document.doc_id,))
            cursor.execute('DELETE FROM nodes WHERE doc_id = ?', (document.doc_id,))
            
            # 保存所有节点
            if document.root:
                self._save_node_recursive(document.root, document.doc_id, cursor)
            
            # 提交事务
            cursor.execute('COMMIT')
            
            self.logger.info(f"Saved document {document.doc_id} with {document.node_count} nodes")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to save document {document.doc_id}: {str(e)}")
            cursor.execute('ROLLBACK')
            return False
    
    def _save_node_recursive(self, node: DocumentNode, doc_id: int, cursor):
        """
        递归保存节点
        
        Args:
            node: 要保存的节点
            doc_id: 文档ID
            cursor: 数据库游标
        """
        current_time = time.time()
        
        # 保存节点数据
        vector_blob = None
        if node.vector is not None:
            vector_blob = sqlite3.Binary(node.vector.tobytes())
        
        cursor.execute('''
        INSERT OR REPLACE INTO nodes 
        (node_id, doc_id, parent_id, content, level, vector, metadata, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            node.node_id,
            doc_id,
            node.parent.node_id if node.parent else None,
            node.content,
            node.level,
            vector_blob,
            json.dumps(node.metadata, ensure_ascii=False),
            current_time,
            current_time
        ))
        
        # 保存坐标信息
        coord_info = CoordinateSystem.parse_coordinate(node.node_id)
        cursor.execute('''
        INSERT OR REPLACE INTO coordinates (node_id, doc_id, coordinate, level_count, levels)
        VALUES (?, ?, ?, ?, ?)
        ''', (
            node.node_id,
            doc_id,
            node.node_id,
            coord_info['level_count'],
            json.dumps(coord_info['levels'])
        ))
        
        # 递归保存子节点
        for child in node.children:
            self._save_node_recursive(child, doc_id, cursor)
    
    def load_document(self, doc_id: int) -> Optional[Document]:
        """
        从数据库加载文档
        
        Args:
            doc_id: 文档ID
            
        Returns:
            文档对象，如果不存在返回None
        """
        cursor = self.conn.cursor()
        
        try:
            # 加载文档元数据
            cursor.execute('SELECT title, created_at, updated_at, metadata FROM documents WHERE doc_id = ?', 
                          (doc_id,))
            result = cursor.fetchone()
            if not result:
                return None
            
            title, created_at, updated_at, metadata_str = result
            
            # 创建文档对象
            document = Document(doc_id, title)
            document.created_at = created_at
            document.updated_at = updated_at
            document.metadata = json.loads(metadata_str) if metadata_str else {}
            
            # 加载所有节点
            nodes = {}
            cursor.execute('''
            SELECT node_id, parent_id, content, level, vector, metadata 
            FROM nodes WHERE doc_id = ?
            ORDER BY level, node_id
            ''', (doc_id,))
            
            for row in cursor.fetchall():
                node_id, parent_id, content, level, vector_blob, metadata_str = row
                
                # 创建节点
                node = DocumentNode(node_id, content, level)
                
                # 加载词向量
                if vector_blob:
                    vector = np.frombuffer(vector_blob, dtype=np.float32)
                    node.vector = vector
                
                # 加载元数据
                node.metadata = json.loads(metadata_str) if metadata_str else {}
                
                nodes[node_id] = node
            
            # 建立父子关系
            root_node = None
            for node_id, node in nodes.items():
                # 查找父节点ID
                cursor.execute('SELECT parent_id FROM nodes WHERE node_id = ?', (node_id,))
                parent_result = cursor.fetchone()
                parent_id = parent_result[0] if parent_result else None
                
                if parent_id is None:
                    # 这是根节点
                    root_node = node
                    document.set_root(node)
                else:
                    # 建立父子关系
                    parent = nodes.get(parent_id)
                    if parent:
                        parent.add_child(node)
                        
                # 添加到文档坐标映射
                document.coordinate_map[node_id] = node
            
            # 更新节点计数
            document.node_count = len(nodes)
            
            self.logger.info(f"Loaded document {doc_id} with {document.node_count} nodes")
            return document
            
        except Exception as e:
            self.logger.error(f"Failed to load document {doc_id}: {str(e)}")
            return None
    
    def delete_document(self, doc_id: int) -> bool:
        """
        删除文档及其所有节点
        
        Args:
            doc_id: 文档ID
            
        Returns:
            True如果删除成功，False否则
        """
        cursor = self.conn.cursor()
        
        try:
            cursor.execute('BEGIN TRANSACTION')
            
            # 删除坐标数据
            cursor.execute('DELETE FROM coordinates WHERE doc_id = ?', (doc_id,))
            
            # 删除节点数据
            cursor.execute('DELETE FROM nodes WHERE doc_id = ?', (doc_id,))
            
            # 删除文档数据
            cursor.execute('DELETE FROM documents WHERE doc_id = ?', (doc_id,))
            
            cursor.execute('COMMIT')
            
            self.logger.info(f"Deleted document {doc_id}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to delete document {doc_id}: {str(e)}")
            cursor.execute('ROLLBACK')
            return False
    
    def list_documents(self, limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """
        列出文档
        
        Args:
            limit: 返回数量限制
            offset: 偏移量
            
        Returns:
            文档信息列表
        """
        cursor = self.conn.cursor()
        
        try:
            cursor.execute('''
            SELECT d.doc_id, d.title, d.created_at, d.updated_at, COUNT(n.node_id) as node_count
            FROM documents d
            LEFT JOIN nodes n ON d.doc_id = n.doc_id
            GROUP BY d.doc_id, d.title, d.created_at, d.updated_at
            ORDER BY d.updated_at DESC
            LIMIT ? OFFSET ?
            ''', (limit, offset))
            
            documents = []
            for row in cursor.fetchall():
                doc_id, title, created_at, updated_at, node_count = row
                documents.append({
                    'doc_id': doc_id,
                    'title': title,
                    'created_at': created_at,
                    'updated_at': updated_at,
                    'node_count': node_count
                })
            
            return documents
            
        except Exception as e:
            self.logger.error(f"Failed to list documents: {str(e)}")
            return []
    
    def search_nodes(self, query: str, doc_id: Optional[int] = None, limit: int = 50) -> List[Dict[str, Any]]:
        """
        搜索节点内容
        
        Args:
            query: 搜索查询
            doc_id: 限制搜索的文档ID，None表示搜索所有文档
            limit: 返回数量限制
            
        Returns:
            匹配的节点列表
        """
        cursor = self.conn.cursor()
        
        try:
            if doc_id:
                cursor.execute('''
                SELECT n.node_id, n.doc_id, n.content, n.level, d.title as doc_title
                FROM nodes n
                JOIN documents d ON n.doc_id = d.doc_id
                WHERE n.doc_id = ? AND n.content LIKE ?
                ORDER BY n.level, n.node_id
                LIMIT ?
                ''', (doc_id, f'%{query}%', limit))
            else:
                cursor.execute('''
                SELECT n.node_id, n.doc_id, n.content, n.level, d.title as doc_title
                FROM nodes n
                JOIN documents d ON n.doc_id = d.doc_id
                WHERE n.content LIKE ?
                ORDER BY d.doc_id, n.level, n.node_id
                LIMIT ?
                ''', (f'%{query}%', limit))
            
            results = []
            for row in cursor.fetchall():
                node_id, doc_id, content, level, doc_title = row
                results.append({
                    'node_id': node_id,
                    'doc_id': doc_id,
                    'doc_title': doc_title,
                    'content': content,
                    'level': level,
                    'coordinate': CoordinateSystem.format_coordinate(node_id)
                })
            
            return results
            
        except Exception as e:
            self.logger.error(f"Failed to search nodes: {str(e)}")
            return []
    
    def get_node_hierarchy(self, node_id: int) -> Optional[Dict[str, Any]]:
        """
        获取节点的层级结构信息
        
        Args:
            node_id: 节点ID
            
        Returns:
            层级结构信息
        """
        cursor = self.conn.cursor()
        
        try:
            # 获取节点信息
            cursor.execute('''
            SELECT n.node_id, n.doc_id, n.parent_id, n.content, n.level, d.title as doc_title
            FROM nodes n
            JOIN documents d ON n.doc_id = d.doc_id
            WHERE n.node_id = ?
            ''', (node_id,))
            
            result = cursor.fetchone()
            if not result:
                return None
            
            node_id, doc_id, parent_id, content, level, doc_title = result
            
            # 获取路径（从根到当前节点）
            path = []
            current_id = node_id
            
            while current_id:
                cursor.execute('SELECT node_id, parent_id, content FROM nodes WHERE node_id = ?', 
                              (current_id,))
                node_result = cursor.fetchone()
                if not node_result:
                    break
                    
                path_node_id, path_parent_id, path_content = node_result
                path.insert(0, {
                    'node_id': path_node_id,
                    'content': path_content,
                    'coordinate': CoordinateSystem.format_coordinate(path_node_id)
                })
                
                current_id = path_parent_id
            
            # 获取子节点
            cursor.execute('SELECT node_id, content FROM nodes WHERE parent_id = ? ORDER BY node_id', 
                          (node_id,))
            children = []
            for child_row in cursor.fetchall():
                child_id, child_content = child_row
                children.append({
                    'node_id': child_id,
                    'content': child_content,
                    'coordinate': CoordinateSystem.format_coordinate(child_id)
                })
            
            return {
                'node_id': node_id,
                'doc_id': doc_id,
                'doc_title': doc_title,
                'content': content,
                'level': level,
                'coordinate': CoordinateSystem.format_coordinate(node_id),
                'path': path,
                'children': children
            }
            
        except Exception as e:
            self.logger.error(f"Failed to get node hierarchy for {node_id}: {str(e)}")
            return None
    
    def backup_database(self, backup_path: str) -> bool:
        """
        备份数据库
        
        Args:
            backup_path: 备份文件路径
            
        Returns:
            True如果备份成功，False否则
        """
        try:
            backup_conn = sqlite3.connect(backup_path)
            self.conn.backup(backup_conn)
            backup_conn.close()
            
            self.logger.info(f"Database backed up to {backup_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to backup database: {str(e)}")
            return False
    
    def get_database_statistics(self) -> Dict[str, Any]:
        """
        获取数据库统计信息
        
        Returns:
            统计信息字典
        """
        cursor = self.conn.cursor()
        
        try:
            # 文档数量
            cursor.execute('SELECT COUNT(*) FROM documents')
            doc_count = cursor.fetchone()[0]
            
            # 节点数量
            cursor.execute('SELECT COUNT(*) FROM nodes')
            node_count = cursor.fetchone()[0]
            
            # 总内容长度
            cursor.execute('SELECT SUM(LENGTH(content)) FROM nodes')
            total_content_length = cursor.fetchone()[0] or 0
            
            # 层级分布
            cursor.execute('SELECT level, COUNT(*) FROM nodes GROUP BY level ORDER BY level')
            level_distribution = dict(cursor.fetchall())
            
            # 数据库文件大小
            cursor.execute('PRAGMA page_count')
            page_count = cursor.fetchone()[0]
            cursor.execute('PRAGMA page_size')
            page_size = cursor.fetchone()[0]
            db_size = page_count * page_size
            
            return {
                'document_count': doc_count,
                'node_count': node_count,
                'total_content_length': total_content_length,
                'average_content_length': total_content_length / node_count if node_count > 0 else 0,
                'level_distribution': level_distribution,
                'database_size_bytes': db_size,
                'database_path': self.db_path
            }
            
        except Exception as e:
            self.logger.error(f"Failed to get database statistics: {str(e)}")
            return {}
    
    def close(self):
        """关闭数据库连接"""
        if self.conn:
            self.conn.close()
            self.logger.info("Database connection closed")
    
    def __del__(self):
        """析构函数"""
        self.close()