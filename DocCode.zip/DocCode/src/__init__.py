"""
GrowDoc - 分层文档结构管理系统

一个基于64位坐标系统和LLM驱动优化的文档管理系统。
"""

__version__ = "0.1.0"
__author__ = "GrowDoc Team"

from .coordinate_system import CoordinateSystem
from .document_node import DocumentNode
from .document import Document
from .llm_service import LLMService
from .document_manager import DocumentManager
from .persistence_manager import PersistenceManager

__all__ = [
    'CoordinateSystem',
    'DocumentNode', 
    'Document',
    'LLMService',
    'DocumentManager',
    'PersistenceManager'
]