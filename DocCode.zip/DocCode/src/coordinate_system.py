"""
GrowDoc 坐标系统实现

实现64位文档内绝对坐标系统：
[0:3] levelcount (4位)
[4:9] level1 (6位)
[10:15] level2 (6位)
[16:21] level3 (6位)
[22:27] level4 (6位)
[28:33] level5 (6位)
[34:39] level6 (6位)
[40:63] 保留位 (24位)
"""


class CoordinateSystem:
    """文档坐标系统管理类"""
    
    @staticmethod
    def create_coordinate(level_count: int, levels: list) -> int:
        """
        创建64位文档内绝对坐标
        
        Args:
            level_count: 层级数量 (1-6)
            levels: 各层级的索引值列表 (每个值0-63)
            
        Returns:
            64位整数坐标
            
        Raises:
            ValueError: 当参数超出范围时
        """
        if level_count < 1 or level_count > 6:
            raise ValueError("Level count must be between 1 and 6")
            
        if len(levels) != level_count:
            raise ValueError("Number of levels must match level_count")
            
        for level in levels:
            if level < 0 or level > 63:
                raise ValueError("Each level must be between 0 and 63")
        
        coord = 0
        
        # 设置层级数量 (高4位)
        coord |= (level_count & 0xF) << 60
        
        # 设置各层级索引 (从高位开始)
        for i in range(6):
            if i < len(levels):
                shift = 54 - (i * 6)  # 计算位移量
                coord |= (levels[i] & 0x3F) << shift
        
        return coord
    
    @staticmethod
    def parse_coordinate(coord: int) -> dict:
        """
        解析坐标返回层级信息
        
        Args:
            coord: 64位坐标值
            
        Returns:
            包含层级信息的字典
        """
        if coord < 0:
            raise ValueError("Coordinate must be non-negative")
            
        # 提取层级数量
        level_count = (coord >> 60) & 0xF
        
        # 提取各层级索引
        levels = []
        for i in range(6):
            if i < level_count:
                shift = 54 - (i * 6)
                level = (coord >> shift) & 0x3F
                levels.append(level)
            else:
                break
        
        return {
            'level_count': level_count,
            'levels': levels
        }
    
    @staticmethod
    def get_parent_coordinate(coord: int) -> int:
        """
        获取父节点坐标
        
        Args:
            coord: 当前节点坐标
            
        Returns:
            父节点坐标，如果是根节点返回None
        """
        coord_info = CoordinateSystem.parse_coordinate(coord)
        
        if coord_info['level_count'] <= 1:
            return None  # 根节点没有父节点
            
        # 创建父节点坐标 (减少一层)
        parent_levels = coord_info['levels'][:-1]
        parent_coord = CoordinateSystem.create_coordinate(
            coord_info['level_count'] - 1, 
            parent_levels
        )
        
        return parent_coord
    
    @staticmethod
    def get_next_sibling_coordinate(coord: int) -> int:
        """
        获取下一个兄弟节点坐标
        
        Args:
            coord: 当前节点坐标
            
        Returns:
            下一个兄弟节点坐标
            
        Raises:
            ValueError: 当达到层级最大索引时
        """
        coord_info = CoordinateSystem.parse_coordinate(coord)
        
        if coord_info['level_count'] == 0:
            raise ValueError("Root node has no siblings")
            
        levels = coord_info['levels'].copy()
        last_level = levels[-1]
        
        if last_level >= 63:
            raise ValueError("Maximum sibling index reached")
            
        levels[-1] = last_level + 1
        
        return CoordinateSystem.create_coordinate(
            coord_info['level_count'],
            levels
        )
    
    @staticmethod
    def is_ancestor(ancestor_coord: int, descendant_coord: int) -> bool:
        """
        检查是否为祖先关系
        
        Args:
            ancestor_coord: 可能的祖先节点坐标
            descendant_coord: 可能的后代节点坐标
            
        Returns:
            True如果是祖先关系，False否则
        """
        ancestor_info = CoordinateSystem.parse_coordinate(ancestor_coord)
        descendant_info = CoordinateSystem.parse_coordinate(descendant_coord)
        
        # 祖先的层级必须小于后代
        if ancestor_info['level_count'] >= descendant_info['level_count']:
            return False
            
        # 检查路径前缀是否匹配
        ancestor_levels = ancestor_info['levels']
        descendant_levels = descendant_info['levels']
        
        for i in range(len(ancestor_levels)):
            if ancestor_levels[i] != descendant_levels[i]:
                return False
                
        return True
    
    @staticmethod
    def format_coordinate(coord: int) -> str:
        """
        格式化坐标为可读字符串
        
        Args:
            coord: 坐标值
            
        Returns:
            格式化的坐标字符串
        """
        coord_info = CoordinateSystem.parse_coordinate(coord)
        
        if coord_info['level_count'] == 0:
            return "ROOT"
            
        level_str = ".".join(str(level) for level in coord_info['levels'])
        return f"L{coord_info['level_count']}:{level_str}"