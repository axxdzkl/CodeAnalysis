"""
GrowDoc 文档管理器实现
"""
import numpy as np
import logging
import time
from typing import Dict, List, Optional, Any, Union
from .document import Document
from .document_node import DocumentNode
from .coordinate_system import CoordinateSystem
from .llm_service import LLMService


class DocumentManager:
    """文档管理器类"""
    
    def __init__(self, vector_model, llm_service: LLMService):
        """
        初始化文档管理器
        
        Args:
            vector_model: 词向量模型
            llm_service: LLM服务实例
        """
        self.vector_model = vector_model
        self.llm_service = llm_service
        self.documents: Dict[int, Document] = {}
        self.next_doc_id = 1
        self.logger = logging.getLogger(__name__)
        
    def create_document(self, title: str, initial_content: str = "") -> int:
        """
        创建新文档
        
        Args:
            title: 文档标题
            initial_content: 初始内容
            
        Returns:
            新创建的文档ID
        """
        try:
            doc_id = self.next_doc_id
            self.next_doc_id += 1
            
            # 创建文档对象
            doc = Document(doc_id, title)
            
            # 创建根节点
            root_coord = CoordinateSystem.create_coordinate(1, [0])
            root_content = initial_content if initial_content else title
            root = DocumentNode(root_coord, root_content, 0)
            
            # 生成词向量
            root.vector = self._encode_text(root_content)
            
            # 设置根节点
            doc.set_root(root)
            
            # 存储文档
            self.documents[doc_id] = doc
            
            self.logger.info(f"Created document {doc_id}: {title}")
            return doc_id
            
        except Exception as e:
            self.logger.error(f"Failed to create document: {str(e)}")
            raise
    
    def get_document(self, doc_id: int) -> Optional[Document]:
        """
        获取文档
        
        Args:
            doc_id: 文档ID
            
        Returns:
            文档对象，如果不存在返回None
        """
        return self.documents.get(doc_id)
    
    def delete_document(self, doc_id: int) -> bool:
        """
        删除文档
        
        Args:
            doc_id: 文档ID
            
        Returns:
            True如果删除成功，False如果文档不存在
        """
        if doc_id in self.documents:
            del self.documents[doc_id]
            self.logger.info(f"Deleted document {doc_id}")
            return True
        return False
    
    def add_node(self, doc_id: int, parent_coord: int, content: str, position: Optional[int] = None) -> int:
        """
        添加新节点
        
        Args:
            doc_id: 文档ID
            parent_coord: 父节点坐标
            content: 节点内容
            position: 在兄弟节点中的位置（可选）
            
        Returns:
            新节点的坐标
            
        Raises:
            ValueError: 当文档不存在或父节点不存在时
        """
        doc = self.documents.get(doc_id)
        if not doc:
            raise ValueError(f"Document {doc_id} not found")
        
        parent = doc.get_node(parent_coord)
        if not parent:
            raise ValueError(f"Parent node {parent_coord} not found")
        
        try:
            # 解析父节点坐标
            parent_info = CoordinateSystem.parse_coordinate(parent_coord)
            new_level = parent_info['level_count']
            
            # 检查层级限制
            if new_level >= 6:
                self.logger.warning(f"Maximum document depth reached for doc {doc_id}")
                # 触发结构优化
                self.optimize_document(doc_id)
                # 重新检查
                if new_level >= 6:
                    raise ValueError("Maximum document depth reached even after optimization")
            
            # 获取同级兄弟节点数量
            siblings = self._get_siblings_at_level(parent, new_level + 1)
            
            # 检查是否需要优化
            if len(siblings) >= 64:
                self.logger.warning(f"Too many siblings at level {new_level + 1} for doc {doc_id}")
                self.optimize_document(doc_id)
                # 重新获取兄弟节点
                siblings = self._get_siblings_at_level(parent, new_level + 1)
                
                if len(siblings) >= 64:
                    raise ValueError("Too many siblings even after optimization")
            
            # 确定新节点的位置
            if position is not None and 0 <= position <= len(siblings):
                sibling_index = position
                # 需要调整后续兄弟节点的坐标
                self._adjust_sibling_coordinates(parent, sibling_index, new_level + 1)
            else:
                sibling_index = len(siblings)
            
            # 创建新节点坐标
            new_levels = parent_info['levels'] + [sibling_index]
            new_coord = CoordinateSystem.create_coordinate(new_level + 1, new_levels)
            
            # 创建新节点
            new_node = DocumentNode(new_coord, content, new_level)
            new_node.vector = self._encode_text(content)
            
            # 建立父子关系
            parent.add_child(new_node)
            
            # 如果指定了位置，调整子节点顺序
            if position is not None and position < len(parent.children) - 1:
                # 移动到指定位置
                parent.children.remove(new_node)
                parent.children.insert(position, new_node)
            
            # 添加到文档
            doc.add_node(new_node)
            
            self.logger.info(f"Added node {new_coord} to document {doc_id}")
            return new_coord
            
        except Exception as e:
            self.logger.error(f"Failed to add node to document {doc_id}: {str(e)}")
            raise
    
    def _get_siblings_at_level(self, parent: DocumentNode, level: int) -> List[DocumentNode]:
        """
        获取父节点下指定层级的子节点
        
        Args:
            parent: 父节点
            level: 目标层级
            
        Returns:
            同级子节点列表
        """
        return [child for child in parent.children 
                if CoordinateSystem.parse_coordinate(child.node_id)['level_count'] == level]
    
    def _adjust_sibling_coordinates(self, parent: DocumentNode, insert_position: int, level: int):
        """
        调整兄弟节点坐标
        
        Args:
            parent: 父节点
            insert_position: 插入位置
            level: 层级
        """
        siblings = self._get_siblings_at_level(parent, level)
        
        for i, sibling in enumerate(siblings):
            if i >= insert_position:
                # 需要更新坐标
                coord_info = CoordinateSystem.parse_coordinate(sibling.node_id)
                new_levels = coord_info['levels'].copy()
                new_levels[-1] = i + 1  # 向后移动一位
                
                new_coord = CoordinateSystem.create_coordinate(
                    coord_info['level_count'],
                    new_levels
                )
                
                # 更新节点坐标
                old_coord = sibling.node_id
                sibling.node_id = new_coord
                
                # 更新文档的坐标映射
                doc = None
                for document in self.documents.values():
                    if old_coord in document.coordinate_map:
                        doc = document
                        break
                
                if doc:
                    del doc.coordinate_map[old_coord]
                    doc.coordinate_map[new_coord] = sibling
    
    def update_node_content(self, doc_id: int, node_coord: int, new_content: str) -> bool:
        """
        更新节点内容
        
        Args:
            doc_id: 文档ID
            node_coord: 节点坐标
            new_content: 新内容
            
        Returns:
            True如果更新成功，False否则
        """
        doc = self.documents.get(doc_id)
        if not doc:
            return False
            
        node = doc.get_node(node_coord)
        if not node:
            return False
        
        try:
            node.update_content(new_content)
            node.vector = self._encode_text(new_content)
            doc.updated_at = time.time()
            
            self.logger.info(f"Updated content for node {node_coord} in document {doc_id}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to update node content: {str(e)}")
            return False
    
    def delete_node(self, doc_id: int, node_coord: int) -> bool:
        """
        删除节点
        
        Args:
            doc_id: 文档ID
            node_coord: 节点坐标
            
        Returns:
            True如果删除成功，False否则
        """
        doc = self.documents.get(doc_id)
        if not doc:
            return False
        
        try:
            success = doc.remove_node(node_coord)
            if success:
                self.logger.info(f"Deleted node {node_coord} from document {doc_id}")
            return success
            
        except Exception as e:
            self.logger.error(f"Failed to delete node: {str(e)}")
            return False
    
    def move_node(self, doc_id: int, node_coord: int, new_parent_coord: int, position: Optional[int] = None) -> bool:
        """
        移动节点到新位置
        
        Args:
            doc_id: 文档ID
            node_coord: 要移动的节点坐标
            new_parent_coord: 新父节点坐标
            position: 在新父节点子节点中的位置
            
        Returns:
            True如果移动成功，False否则
        """
        doc = self.documents.get(doc_id)
        if not doc:
            return False
        
        try:
            # 这里简化实现，实际应该重新分配坐标
            success = doc.move_node(node_coord, new_parent_coord)
            if success:
                self.logger.info(f"Moved node {node_coord} to {new_parent_coord} in document {doc_id}")
            return success
            
        except Exception as e:
            self.logger.error(f"Failed to move node: {str(e)}")
            return False
    
    def optimize_document(self, doc_id: int) -> Dict[str, Any]:
        """
        优化文档结构
        
        Args:
            doc_id: 文档ID
            
        Returns:
            优化结果字典
        """
        doc = self.documents.get(doc_id)
        if not doc:
            return {"error": "Document not found"}
        
        try:
            # 使用LLM服务进行优化
            optimization_result = self.llm_service.optimize_structure(doc)
            
            # 应用优化建议
            applied_optimizations = self._apply_optimizations(doc, optimization_result.get('optimizations', []))
            
            result = {
                "doc_id": doc_id,
                "optimizations_suggested": len(optimization_result.get('optimizations', [])),
                "optimizations_applied": len(applied_optimizations),
                "applied_optimizations": applied_optimizations,
                "reasoning": optimization_result.get('reasoning', ''),
                "success": True
            }
            
            self.logger.info(f"Optimized document {doc_id}: {len(applied_optimizations)} optimizations applied")
            return result
            
        except Exception as e:
            self.logger.error(f"Failed to optimize document {doc_id}: {str(e)}")
            return {
                "doc_id": doc_id,
                "error": str(e),
                "success": False
            }
    
    def _apply_optimizations(self, document: Document, optimizations: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        应用优化建议
        
        Args:
            document: 文档对象
            optimizations: 优化建议列表
            
        Returns:
            实际应用的优化列表
        """
        applied = []
        
        for opt in optimizations:
            try:
                if self._apply_single_optimization(document, opt):
                    applied.append(opt)
                    self.logger.info(f"Applied optimization: {opt['type']} on node {opt.get('target_node_id')}")
                else:
                    self.logger.warning(f"Failed to apply optimization: {opt}")
                    
            except Exception as e:
                self.logger.error(f"Error applying optimization {opt}: {str(e)}")
        
        return applied
    
    def _apply_single_optimization(self, document: Document, optimization: Dict[str, Any]) -> bool:
        """
        应用单个优化建议
        
        Args:
            document: 文档对象
            optimization: 优化建议
            
        Returns:
            True如果应用成功，False否则
        """
        opt_type = optimization.get('type')
        target_id = optimization.get('target_node_id')
        
        if not target_id:
            return False
            
        try:
            target_id = int(target_id)
        except (ValueError, TypeError):
            return False
        
        target_node = document.get_node(target_id)
        if not target_node:
            return False
        
        # 简化的优化应用逻辑
        if opt_type == 'reorder':
            return self._reorder_children(target_node)
        elif opt_type == 'group':
            return self._group_similar_children(target_node)
        elif opt_type == 'merge':
            return self._merge_similar_children(target_node)
        elif opt_type == 'split':
            return self._split_large_node(target_node, document)
        
        return False
    
    def _reorder_children(self, node: DocumentNode) -> bool:
        """重新排序子节点"""
        if len(node.children) <= 1:
            return False
        
        # 简单按内容长度排序
        node.children.sort(key=lambda x: len(x.content))
        return True
    
    def _group_similar_children(self, node: DocumentNode) -> bool:
        """将相似的子节点分组"""
        # 简化实现：按内容相似性分组
        return len(node.children) > 2
    
    def _merge_similar_children(self, node: DocumentNode) -> bool:
        """合并相似的子节点"""
        # 简化实现
        return len(node.children) > 1
    
    def _split_large_node(self, node: DocumentNode, document: Document) -> bool:
        """拆分大节点"""
        if len(node.content) < 200:
            return False
        
        # 简化实现：如果内容很长，建议拆分
        return True
    
    def search_documents(self, query: str, doc_ids: Optional[List[int]] = None) -> List[Dict[str, Any]]:
        """
        搜索文档内容
        
        Args:
            query: 搜索查询
            doc_ids: 要搜索的文档ID列表，None表示搜索所有文档
            
        Returns:
            搜索结果列表
        """
        results = []
        
        target_docs = doc_ids if doc_ids else list(self.documents.keys())
        
        for doc_id in target_docs:
            doc = self.documents.get(doc_id)
            if not doc:
                continue
                
            # 在文档中搜索
            matches = doc.search_by_content(query)
            
            for match in matches:
                results.append({
                    'doc_id': doc_id,
                    'doc_title': doc.title,
                    'node_id': match.node_id,
                    'node_content': match.content,
                    'node_coordinate': match.get_formatted_coordinate(),
                    'relevance_score': self._calculate_relevance(query, match.content)
                })
        
        # 按相关性排序
        results.sort(key=lambda x: x['relevance_score'], reverse=True)
        
        return results
    
    def _calculate_relevance(self, query: str, content: str) -> float:
        """
        计算相关性得分
        
        Args:
            query: 查询字符串
            content: 内容字符串
            
        Returns:
            相关性得分
        """
        # 简化的相关性计算
        query_lower = query.lower()
        content_lower = content.lower()
        
        if query_lower in content_lower:
            # 精确匹配得高分
            return 1.0
        
        # 词汇重叠度
        query_words = set(query_lower.split())
        content_words = set(content_lower.split())
        
        if not query_words:
            return 0.0
        
        overlap = len(query_words.intersection(content_words))
        return overlap / len(query_words)
    
    def _encode_text(self, text: str) -> np.ndarray:
        """
        编码文本为词向量
        
        Args:
            text: 文本内容
            
        Returns:
            词向量数组
        """
        try:
            if hasattr(self.vector_model, 'encode'):
                return self.vector_model.encode(text)
            else:
                # 降级到随机向量
                return np.random.rand(384).astype(np.float32)
        except Exception as e:
            self.logger.warning(f"Failed to encode text, using random vector: {str(e)}")
            return np.random.rand(384).astype(np.float32)
    
    def get_statistics(self) -> Dict[str, Any]:
        """
        获取管理器统计信息
        
        Returns:
            统计信息字典
        """
        total_nodes = sum(doc.node_count for doc in self.documents.values())
        total_content_length = 0
        
        for doc in self.documents.values():
            for node in doc.coordinate_map.values():
                total_content_length += len(node.content)
        
        return {
            'total_documents': len(self.documents),
            'total_nodes': total_nodes,
            'total_content_length': total_content_length,
            'average_nodes_per_document': total_nodes / len(self.documents) if self.documents else 0,
            'next_doc_id': self.next_doc_id
        }