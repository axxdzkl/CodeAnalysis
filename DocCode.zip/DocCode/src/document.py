"""
GrowDoc 文档类实现
"""
from typing import Dict, Optional, List, Any
from .document_node import DocumentNode
from .coordinate_system import CoordinateSystem
import time


class Document:
    """文档类"""
    
    def __init__(self, doc_id: int, title: str):
        """
        初始化文档
        
        Args:
            doc_id: 32位文档ID
            title: 文档标题
        """
        self.doc_id = doc_id
        self.title = title
        self.root: Optional[DocumentNode] = None
        self.node_count = 0
        self.coordinate_map: Dict[int, DocumentNode] = {}  # 坐标到节点的映射
        self.created_at = time.time()
        self.updated_at = time.time()
        self.metadata: Dict[str, Any] = {}
        
    def set_root(self, root_node: DocumentNode):
        """
        设置根节点
        
        Args:
            root_node: 根节点
        """
        self.root = root_node
        self.coordinate_map[root_node.node_id] = root_node
        self.node_count = 1
        self.updated_at = time.time()
        
    def add_node(self, node: DocumentNode):
        """
        添加节点到文档
        
        Args:
            node: 要添加的节点
            
        Raises:
            ValueError: 当节点ID已存在时
        """
        if node.node_id in self.coordinate_map:
            raise ValueError(f"Node with ID {node.node_id} already exists")
            
        self.coordinate_map[node.node_id] = node
        self.node_count += 1
        self.updated_at = time.time()
        
    def remove_node(self, node_id: int) -> bool:
        """
        移除节点
        
        Args:
            node_id: 要移除的节点ID
            
        Returns:
            True如果成功移除，False如果节点不存在
        """
        if node_id not in self.coordinate_map:
            return False
            
        node = self.coordinate_map[node_id]
        
        # 不能移除根节点
        if node.is_root():
            raise ValueError("Cannot remove root node")
            
        # 移除节点及其所有后代
        nodes_to_remove = [node] + node.get_descendants()
        
        for node_to_remove in nodes_to_remove:
            if node_to_remove.node_id in self.coordinate_map:
                del self.coordinate_map[node_to_remove.node_id]
                self.node_count -= 1
                
        # 从父节点中移除
        if node.parent:
            node.parent.remove_child(node)
            
        self.updated_at = time.time()
        return True
        
    def get_node(self, node_id: int) -> Optional[DocumentNode]:
        """
        根据ID获取节点
        
        Args:
            node_id: 节点ID
            
        Returns:
            节点对象，如果不存在返回None
        """
        return self.coordinate_map.get(node_id)
        
    def get_nodes_by_level(self, level: int) -> List[DocumentNode]:
        """
        获取指定层级的所有节点
        
        Args:
            level: 层级
            
        Returns:
            指定层级的节点列表
        """
        return [node for node in self.coordinate_map.values() if node.level == level]
        
    def get_leaf_nodes(self) -> List[DocumentNode]:
        """
        获取所有叶子节点
        
        Returns:
            叶子节点列表
        """
        return [node for node in self.coordinate_map.values() if node.is_leaf()]
        
    def get_max_depth(self) -> int:
        """
        获取文档最大深度
        
        Returns:
            最大深度
        """
        if not self.coordinate_map:
            return 0
        return max(node.get_depth() for node in self.coordinate_map.values())
        
    def search_by_content(self, query: str, case_sensitive: bool = False) -> List[DocumentNode]:
        """
        根据内容搜索节点
        
        Args:
            query: 搜索查询
            case_sensitive: 是否区分大小写
            
        Returns:
            匹配的节点列表
        """
        results = []
        
        for node in self.coordinate_map.values():
            content = node.content if case_sensitive else node.content.lower()
            search_query = query if case_sensitive else query.lower()
            
            if search_query in content:
                results.append(node)
                
        return results
        
    def get_siblings_of_node(self, node_id: int) -> List[DocumentNode]:
        """
        获取节点的兄弟节点
        
        Args:
            node_id: 节点ID
            
        Returns:
            兄弟节点列表
        """
        node = self.get_node(node_id)
        if node is None:
            return []
        return node.get_siblings()
        
    def get_children_of_node(self, node_id: int) -> List[DocumentNode]:
        """
        获取节点的子节点
        
        Args:
            node_id: 节点ID
            
        Returns:
            子节点列表
        """
        node = self.get_node(node_id)
        if node is None:
            return []
        return node.children.copy()
        
    def get_descendants_of_node(self, node_id: int) -> List[DocumentNode]:
        """
        获取节点的所有后代
        
        Args:
            node_id: 节点ID
            
        Returns:
            后代节点列表
        """
        node = self.get_node(node_id)
        if node is None:
            return []
        return node.get_descendants()
        
    def move_node(self, node_id: int, new_parent_id: int) -> bool:
        """
        移动节点到新父节点下
        
        Args:
            node_id: 要移动的节点ID
            new_parent_id: 新父节点ID
            
        Returns:
            True如果移动成功，False否则
        """
        node = self.get_node(node_id)
        new_parent = self.get_node(new_parent_id)
        
        if node is None or new_parent is None:
            return False
            
        # 不能移动根节点
        if node.is_root():
            return False
            
        # 不能移动到自己的后代节点
        if node_id == new_parent_id or new_parent in node.get_descendants():
            return False
            
        # 从原父节点移除
        if node.parent:
            node.parent.remove_child(node)
            
        # 添加到新父节点
        new_parent.add_child(node)
        
        # 更新层级和坐标（这里简化处理，实际应该重新分配坐标）
        self._update_node_levels(node, new_parent.level + 1)
        
        self.updated_at = time.time()
        return True
        
    def _update_node_levels(self, node: DocumentNode, new_level: int):
        """
        递归更新节点及其后代的层级
        
        Args:
            node: 要更新的节点
            new_level: 新层级
        """
        node.level = new_level
        for child in node.children:
            self._update_node_levels(child, new_level + 1)
            
    def validate_structure(self) -> Dict[str, Any]:
        """
        验证文档结构的完整性
        
        Returns:
            验证结果字典
        """
        issues = []
        warnings = []
        
        # 检查根节点
        if self.root is None:
            issues.append("Document has no root node")
            
        # 检查节点计数
        actual_count = len(self.coordinate_map)
        if actual_count != self.node_count:
            issues.append(f"Node count mismatch: expected {self.node_count}, actual {actual_count}")
            
        # 检查坐标映射完整性
        for node in self.coordinate_map.values():
            # 检查父子关系
            if node.parent and node.parent.node_id not in self.coordinate_map:
                issues.append(f"Node {node.node_id} has invalid parent reference")
                
            for child in node.children:
                if child.node_id not in self.coordinate_map:
                    issues.append(f"Node {node.node_id} has invalid child reference")
                    
        # 检查层级深度
        max_depth = self.get_max_depth()
        if max_depth > 6:
            warnings.append(f"Document depth ({max_depth}) exceeds recommended maximum (6)")
            
        return {
            'valid': len(issues) == 0,
            'issues': issues,
            'warnings': warnings,
            'node_count': self.node_count,
            'max_depth': max_depth
        }
        
    def get_statistics(self) -> Dict[str, Any]:
        """
        获取文档统计信息
        
        Returns:
            统计信息字典
        """
        level_counts = {}
        total_content_length = 0
        leaf_count = 0
        
        for node in self.coordinate_map.values():
            # 层级统计
            level_counts[node.level] = level_counts.get(node.level, 0) + 1
            
            # 内容长度统计
            total_content_length += len(node.content)
            
            # 叶子节点统计
            if node.is_leaf():
                leaf_count += 1
                
        return {
            'doc_id': self.doc_id,
            'title': self.title,
            'node_count': self.node_count,
            'max_depth': self.get_max_depth(),
            'leaf_count': leaf_count,
            'level_counts': level_counts,
            'total_content_length': total_content_length,
            'average_content_length': total_content_length / self.node_count if self.node_count > 0 else 0,
            'created_at': self.created_at,
            'updated_at': self.updated_at
        }
        
    def to_dict(self, include_vectors: bool = False) -> Dict[str, Any]:
        """
        将文档转换为字典格式
        
        Args:
            include_vectors: 是否包含词向量
            
        Returns:
            文档字典表示
        """
        def build_tree(node: DocumentNode) -> Dict[str, Any]:
            return node.to_dict(include_vector=include_vectors, include_children=True)
            
        return {
            'doc_id': self.doc_id,
            'title': self.title,
            'node_count': self.node_count,
            'created_at': self.created_at,
            'updated_at': self.updated_at,
            'metadata': self.metadata,
            'statistics': self.get_statistics(),
            'structure': build_tree(self.root) if self.root else None
        }
        
    def __str__(self) -> str:
        """字符串表示"""
        return f"Document({self.doc_id}): {self.title} ({self.node_count} nodes)"
        
    def __repr__(self) -> str:
        """详细字符串表示"""
        return f"Document(id={self.doc_id}, title='{self.title}', nodes={self.node_count})"