"""
GrowDoc LLM优化服务实现
"""
import json
import logging
from typing import Dict, List, Any, Optional
from .document import Document
from .document_node import DocumentNode
from .coordinate_system import CoordinateSystem


class LLMService:
    """LLM驱动的文档结构优化服务"""
    
    def __init__(self, model_name: str = "gpt-3.5-turbo", max_tokens: int = 40000, api_key: Optional[str] = None):
        """
        初始化LLM服务
        
        Args:
            model_name: 模型名称
            max_tokens: 最大令牌数
            api_key: API密钥
        """
        self.model_name = model_name
        self.max_tokens = max_tokens
        self.api_key = api_key
        self.logger = logging.getLogger(__name__)
        
    def optimize_structure(self, document: Document) -> Dict[str, Any]:
        """
        使用LLM优化文档结构
        
        Args:
            document: 要优化的文档
            
        Returns:
            优化建议字典
        """
        try:
            # 构建文档结构摘要
            structure_summary = self._build_structure_summary(document)
            
            # 分析结构问题
            structure_analysis = self._analyze_structure_issues(document)
            
            # 准备LLM提示
            prompt = self._build_optimization_prompt(document, structure_summary, structure_analysis)
            
            # 调用LLM API
            response = self._call_llm(prompt)
            
            # 解析响应
            optimization_result = self._parse_llm_response(response)
            
            # 验证优化建议
            validated_result = self._validate_optimizations(optimization_result, document)
            
            return validated_result
            
        except Exception as e:
            self.logger.error(f"Error in structure optimization: {str(e)}")
            return {
                "optimizations": [],
                "reasoning": f"优化过程出错: {str(e)}",
                "error": True
            }
    
    def _build_structure_summary(self, document: Document) -> str:
        """
        构建文档结构摘要
        
        Args:
            document: 文档对象
            
        Returns:
            结构摘要字符串
        """
        summary = []
        summary.append(f"文档标题: {document.title}")
        summary.append(f"节点总数: {document.node_count}")
        summary.append(f"最大深度: {document.get_max_depth()}")
        summary.append("")
        summary.append("结构树:")
        
        if document.root:
            self._traverse_node_for_summary(document.root, 0, summary)
            
        return "\n".join(summary)
    
    def _traverse_node_for_summary(self, node: DocumentNode, depth: int, summary: List[str]):
        """
        递归遍历节点构建摘要
        
        Args:
            node: 当前节点
            depth: 深度
            summary: 摘要列表
        """
        indent = "  " * depth
        coord_info = CoordinateSystem.parse_coordinate(node.node_id)
        content_preview = node.content[:50] + "..." if len(node.content) > 50 else node.content
        
        summary.append(f"{indent}[{coord_info['level_count']}] {content_preview} (子节点: {len(node.children)})")
        
        # 限制遍历深度以避免输出过长
        if depth < 5:
            for child in node.children:
                self._traverse_node_for_summary(child, depth + 1, summary)
        elif node.children:
            summary.append(f"{indent}  ... ({len(node.children)} 个子节点)")
    
    def _analyze_structure_issues(self, document: Document) -> Dict[str, Any]:
        """
        分析文档结构问题
        
        Args:
            document: 文档对象
            
        Returns:
            问题分析结果
        """
        issues = []
        suggestions = []
        stats = document.get_statistics()
        
        # 检查深度问题
        if stats['max_depth'] > 6:
            issues.append(f"文档深度过深 ({stats['max_depth']} 层)")
            suggestions.append("建议重构深层嵌套的内容")
            
        # 检查节点分布
        level_counts = stats.get('level_counts', {})
        for level, count in level_counts.items():
            if count > 20:
                issues.append(f"第 {level} 层节点过多 ({count} 个)")
                suggestions.append(f"建议对第 {level} 层进行分组或合并")
        
        # 检查叶子节点比例
        leaf_ratio = stats['leaf_count'] / stats['node_count'] if stats['node_count'] > 0 else 0
        if leaf_ratio < 0.3:
            issues.append(f"叶子节点比例过低 ({leaf_ratio:.2%})")
            suggestions.append("可能存在过度分层，建议合并部分中间节点")
        elif leaf_ratio > 0.8:
            issues.append(f"叶子节点比例过高 ({leaf_ratio:.2%})")
            suggestions.append("结构可能过于扁平，建议增加分层")
            
        # 检查内容长度分布
        avg_length = stats.get('average_content_length', 0)
        if avg_length < 10:
            issues.append("节点内容过于简短")
            suggestions.append("建议合并内容较少的相关节点")
        elif avg_length > 500:
            issues.append("节点内容过长")
            suggestions.append("建议拆分内容较多的节点")
            
        return {
            'issues': issues,
            'suggestions': suggestions,
            'statistics': stats
        }
    
    def _build_optimization_prompt(self, document: Document, structure_summary: str, analysis: Dict[str, Any]) -> str:
        """
        构建优化提示
        
        Args:
            document: 文档对象
            structure_summary: 结构摘要
            analysis: 结构分析
            
        Returns:
            优化提示字符串
        """
        prompt = f"""
你是一个专业的文档结构优化专家。请分析以下文档结构并提出优化建议。

{structure_summary}

发现的问题:
{chr(10).join(f"- {issue}" for issue in analysis['issues'])}

建议:
{chr(10).join(f"- {suggestion}" for suggestion in analysis['suggestions'])}

请提供以下格式的JSON响应:
{{
    "optimizations": [
        {{
            "type": "split|merge|reorder|promote|demote|group",
            "target_node_id": "目标节点坐标",
            "description": "操作描述",
            "reason": "操作理由",
            "priority": "high|medium|low",
            "estimated_impact": "预期影响描述"
        }}
    ],
    "reasoning": "整体优化理由和策略",
    "priority_order": ["按优先级排序的操作类型"],
    "expected_benefits": ["预期收益列表"]
}}

操作类型说明:
- split: 将大节点拆分为多个小节点
- merge: 合并相关的小节点
- reorder: 重新排序节点
- promote: 提升节点层级
- demote: 降低节点层级
- group: 将相关节点组织在一起

请确保建议的操作是合理的，不会破坏文档的逻辑结构。
"""
        return prompt
    
    def _call_llm(self, prompt: str) -> str:
        """
        调用LLM API
        
        Args:
            prompt: 提示字符串
            
        Returns:
            LLM响应
        """
        # 在实际实现中，这里会调用OpenAI或其他LLM API
        # 原型中返回模拟响应
        
        mock_response = {
            "optimizations": [
                {
                    "type": "group",
                    "target_node_id": "0",
                    "description": "将相关章节组织到主题分组中",
                    "reason": "提高文档的逻辑结构和可读性",
                    "priority": "medium",
                    "estimated_impact": "改善文档导航和理解"
                }
            ],
            "reasoning": "当前文档结构基本合理，建议进行小幅调整以提高可读性",
            "priority_order": ["group", "reorder", "merge"],
            "expected_benefits": [
                "更清晰的文档结构",
                "更好的导航体验",
                "降低认知负担"
            ]
        }
        
        return json.dumps(mock_response, ensure_ascii=False)
    
    def _parse_llm_response(self, response: str) -> Dict[str, Any]:
        """
        解析LLM响应
        
        Args:
            response: LLM响应字符串
            
        Returns:
            解析后的字典
        """
        try:
            return json.loads(response)
        except json.JSONDecodeError as e:
            self.logger.error(f"Failed to parse LLM response: {e}")
            return {
                "optimizations": [],
                "reasoning": "LLM响应解析失败",
                "error": True
            }
    
    def _validate_optimizations(self, optimization_result: Dict[str, Any], document: Document) -> Dict[str, Any]:
        """
        验证优化建议
        
        Args:
            optimization_result: 优化结果
            document: 文档对象
            
        Returns:
            验证后的结果
        """
        valid_optimizations = []
        
        for opt in optimization_result.get('optimizations', []):
            if self._is_valid_optimization(opt, document):
                valid_optimizations.append(opt)
            else:
                self.logger.warning(f"Invalid optimization skipped: {opt}")
        
        optimization_result['optimizations'] = valid_optimizations
        optimization_result['validation_passed'] = True
        
        return optimization_result
    
    def _is_valid_optimization(self, optimization: Dict[str, Any], document: Document) -> bool:
        """
        检查优化建议是否有效
        
        Args:
            optimization: 优化建议
            document: 文档对象
            
        Returns:
            True如果有效，False否则
        """
        required_fields = ['type', 'target_node_id', 'description']
        
        # 检查必需字段
        for field in required_fields:
            if field not in optimization:
                return False
        
        # 检查操作类型
        valid_types = ['split', 'merge', 'reorder', 'promote', 'demote', 'group']
        if optimization['type'] not in valid_types:
            return False
        
        # 检查目标节点是否存在
        try:
            target_node_id = int(optimization['target_node_id'])
            if document.get_node(target_node_id) is None:
                return False
        except (ValueError, TypeError):
            return False
        
        return True
    
    def generate_content_suggestions(self, node: DocumentNode, context_nodes: List[DocumentNode] = None) -> Dict[str, Any]:
        """
        生成内容改进建议
        
        Args:
            node: 目标节点
            context_nodes: 上下文节点列表
            
        Returns:
            内容建议字典
        """
        try:
            context_content = []
            if context_nodes:
                for ctx_node in context_nodes:
                    context_content.append(f"- {ctx_node.content[:100]}")
            
            prompt = f"""
请为以下文档节点提供内容改进建议:

当前内容: {node.content}

上下文:
{chr(10).join(context_content) if context_content else "无上下文"}

请提供以下格式的JSON响应:
{{
    "suggestions": [
        {{
            "type": "clarity|structure|detail|conciseness",
            "description": "建议描述",
            "example": "改进示例"
        }}
    ],
    "overall_assessment": "整体评估",
    "priority_improvements": ["优先改进点"]
}}
"""
            
            response = self._call_llm(prompt)
            return self._parse_llm_response(response)
            
        except Exception as e:
            self.logger.error(f"Error generating content suggestions: {str(e)}")
            return {
                "suggestions": [],
                "overall_assessment": "内容建议生成失败",
                "error": True
            }
    
    def suggest_new_structure(self, content_items: List[str], theme: str = "") -> Dict[str, Any]:
        """
        为给定内容项建议新的结构
        
        Args:
            content_items: 内容项列表
            theme: 主题或上下文
            
        Returns:
            结构建议字典
        """
        try:
            items_text = "\n".join(f"{i+1}. {item}" for i, item in enumerate(content_items))
            
            prompt = f"""
请为以下内容项设计最佳的文档结构:

主题: {theme if theme else "未指定"}

内容项:
{items_text}

请提供以下格式的JSON响应:
{{
    "suggested_structure": {{
        "title": "建议的根标题",
        "children": [
            {{
                "title": "章节标题",
                "content_items": [1, 2, 3],
                "children": [...]
            }}
        ]
    }},
    "reasoning": "结构设计理由",
    "principles": ["设计原则"]
}}
"""
            
            response = self._call_llm(prompt)
            return self._parse_llm_response(response)
            
        except Exception as e:
            self.logger.error(f"Error suggesting structure: {str(e)}")
            return {
                "suggested_structure": None,
                "reasoning": "结构建议生成失败",
                "error": True
            }