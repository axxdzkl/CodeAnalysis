"""
GrowDoc 文档节点结构实现
"""
import numpy as np
from typing import List, Optional, Any
from .coordinate_system import CoordinateSystem


class DocumentNode:
    """文档节点类"""
    
    def __init__(self, node_id: int, content: str, level: int):
        """
        初始化文档节点
        
        Args:
            node_id: 64位文档内绝对坐标
            content: 节点内容
            level: 节点层级深度
        """
        self.node_id = node_id
        self.content = content
        self.level = level
        self.vector: Optional[np.ndarray] = None  # 词向量相对坐标
        self.children: List['DocumentNode'] = []  # 子节点列表
        self.parent: Optional['DocumentNode'] = None  # 父节点引用
        self.metadata: dict = {}  # 额外元数据
        
    def add_child(self, child: 'DocumentNode'):
        """
        添加子节点
        
        Args:
            child: 要添加的子节点
        """
        if child not in self.children:
            self.children.append(child)
            child.parent = self
            
    def remove_child(self, child: 'DocumentNode'):
        """
        移除子节点
        
        Args:
            child: 要移除的子节点
        """
        if child in self.children:
            self.children.remove(child)
            child.parent = None
            
    def get_siblings(self) -> List['DocumentNode']:
        """
        获取兄弟节点列表
        
        Returns:
            兄弟节点列表（不包含自己）
        """
        if self.parent is None:
            return []
        return [child for child in self.parent.children if child != self]
    
    def get_descendants(self) -> List['DocumentNode']:
        """
        获取所有后代节点
        
        Returns:
            后代节点列表
        """
        descendants = []
        for child in self.children:
            descendants.append(child)
            descendants.extend(child.get_descendants())
        return descendants
    
    def get_ancestors(self) -> List['DocumentNode']:
        """
        获取所有祖先节点
        
        Returns:
            祖先节点列表（从父节点到根节点）
        """
        ancestors = []
        current = self.parent
        while current is not None:
            ancestors.append(current)
            current = current.parent
        return ancestors
    
    def get_path(self) -> List['DocumentNode']:
        """
        获取从根节点到当前节点的路径
        
        Returns:
            路径节点列表
        """
        path = self.get_ancestors()
        path.reverse()
        path.append(self)
        return path
    
    def get_depth(self) -> int:
        """
        获取节点深度（从根节点开始计算）
        
        Returns:
            节点深度
        """
        return len(self.get_ancestors())
    
    def is_leaf(self) -> bool:
        """
        判断是否为叶子节点
        
        Returns:
            True如果是叶子节点，False否则
        """
        return len(self.children) == 0
    
    def is_root(self) -> bool:
        """
        判断是否为根节点
        
        Returns:
            True如果是根节点，False否则
        """
        return self.parent is None
    
    def get_subtree_size(self) -> int:
        """
        获取子树大小（包含自己）
        
        Returns:
            子树节点总数
        """
        size = 1  # 自己
        for child in self.children:
            size += child.get_subtree_size()
        return size
    
    def find_child_by_content(self, content: str) -> Optional['DocumentNode']:
        """
        根据内容查找直接子节点
        
        Args:
            content: 要查找的内容
            
        Returns:
            找到的子节点，如果没找到返回None
        """
        for child in self.children:
            if child.content == content:
                return child
        return None
    
    def find_descendant_by_id(self, node_id: int) -> Optional['DocumentNode']:
        """
        根据ID查找后代节点
        
        Args:
            node_id: 要查找的节点ID
            
        Returns:
            找到的节点，如果没找到返回None
        """
        if self.node_id == node_id:
            return self
            
        for child in self.children:
            result = child.find_descendant_by_id(node_id)
            if result is not None:
                return result
        return None
    
    def update_content(self, content: str):
        """
        更新节点内容
        
        Args:
            content: 新的内容
        """
        self.content = content
        # 清除词向量，需要重新计算
        self.vector = None
    
    def set_vector(self, vector: np.ndarray):
        """
        设置词向量
        
        Args:
            vector: 词向量数组
        """
        if not isinstance(vector, np.ndarray):
            raise ValueError("Vector must be a numpy array")
        self.vector = vector.copy()
    
    def get_coordinate_info(self) -> dict:
        """
        获取坐标信息
        
        Returns:
            坐标信息字典
        """
        return CoordinateSystem.parse_coordinate(self.node_id)
    
    def get_formatted_coordinate(self) -> str:
        """
        获取格式化的坐标字符串
        
        Returns:
            格式化的坐标字符串
        """
        return CoordinateSystem.format_coordinate(self.node_id)
    
    def to_dict(self, include_vector: bool = False, include_children: bool = False) -> dict:
        """
        将节点转换为字典格式
        
        Args:
            include_vector: 是否包含词向量
            include_children: 是否包含子节点
            
        Returns:
            节点字典表示
        """
        result = {
            'node_id': self.node_id,
            'content': self.content,
            'level': self.level,
            'coordinate': self.get_formatted_coordinate(),
            'is_leaf': self.is_leaf(),
            'is_root': self.is_root(),
            'children_count': len(self.children),
            'subtree_size': self.get_subtree_size(),
            'metadata': self.metadata.copy()
        }
        
        if include_vector and self.vector is not None:
            result['vector'] = self.vector.tolist()
            
        if include_children:
            result['children'] = [child.to_dict(include_vector, include_children) 
                                for child in self.children]
        
        return result
    
    def __str__(self) -> str:
        """字符串表示"""
        coord_str = self.get_formatted_coordinate()
        return f"Node({coord_str}): {self.content[:50]}{'...' if len(self.content) > 50 else ''}"
    
    def __repr__(self) -> str:
        """详细字符串表示"""
        return f"DocumentNode(id={self.node_id}, level={self.level}, content='{self.content[:30]}...')"
    
    def __eq__(self, other) -> bool:
        """相等性比较"""
        if not isinstance(other, DocumentNode):
            return False
        return self.node_id == other.node_id
    
    def __hash__(self) -> int:
        """哈希值"""
        return hash(self.node_id)