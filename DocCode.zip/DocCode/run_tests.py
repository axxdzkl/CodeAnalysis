"""
测试运行脚本
"""
import sys
import os
import subprocess
import unittest
import time
import signal
import threading
from pathlib import Path

# 添加src目录到Python路径
sys.path.insert(0, str(Path(__file__).parent / "src"))

def run_unit_tests():
    """运行单元测试"""
    print("="*50)
    print("运行单元测试")
    print("="*50)
    
    # 发现并运行测试
    loader = unittest.TestLoader()
    suite = loader.discover('tests', pattern='test_*.py')
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    return result.wasSuccessful()

def start_api_server():
    """启动API服务器"""
    print("启动API服务器...")
    
    # 启动服务器进程
    process = subprocess.Popen([
        sys.executable, "api.py"
    ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    
    # 等待服务器启动
    time.sleep(5)
    
    return process

def run_integration_tests():
    """运行集成测试"""
    print("="*50)
    print("运行集成测试")
    print("="*50)
    
    # 启动API服务器
    server_process = start_api_server()
    
    try:
        # 运行集成测试
        result = subprocess.run([
            sys.executable, "tests/integration_test.py"
        ], capture_output=True, text=True)
        
        print(result.stdout)
        if result.stderr:
            print("STDERR:", result.stderr)
        
        return result.returncode == 0
        
    finally:
        # 停止服务器
        print("停止API服务器...")
        server_process.terminate()
        try:
            server_process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            server_process.kill()

def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description="GrowDoc测试运行器")
    parser.add_argument("--unit-only", action="store_true", help="只运行单元测试")
    parser.add_argument("--integration-only", action="store_true", help="只运行集成测试")
    
    args = parser.parse_args()
    
    success = True
    
    if not args.integration_only:
        print("开始单元测试...")
        unit_success = run_unit_tests()
        if not unit_success:
            print("❌ 单元测试失败")
            success = False
        else:
            print("✅ 单元测试通过")
    
    if not args.unit_only:
        print("\n开始集成测试...")
        integration_success = run_integration_tests()
        if not integration_success:
            print("❌ 集成测试失败")
            success = False
        else:
            print("✅ 集成测试通过")
    
    if success:
        print("\n🎉 所有测试通过!")
        return 0
    else:
        print("\n❌ 部分测试失败")
        return 1

if __name__ == "__main__":
    sys.exit(main())