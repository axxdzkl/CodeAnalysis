"""
GrowDoc Flask API实现
"""
import logging
import traceback
from flask import Flask, request, jsonify
from flask_cors import CORS
import numpy as np

# 设置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# 尝试导入sentence-transformers，如果失败则使用模拟模型
try:
    from sentence_transformers import SentenceTransformer
    vector_model = SentenceTransformer('all-MiniLM-L6-v2')
    logger.info("Loaded SentenceTransformer model")
except ImportError:
    logger.warning("SentenceTransformer not available, using mock vector model")
    class MockVectorModel:
        def encode(self, text):
            # 基于文本内容生成确定性的向量
            import hashlib
            hash_obj = hashlib.md5(text.encode())
            seed = int(hash_obj.hexdigest()[:8], 16)
            np.random.seed(seed)
            return np.random.rand(384).astype(np.float32)
    
    vector_model = MockVectorModel()

# 导入自定义模块
from src.llm_service import LLMService
from src.document_manager import DocumentManager
from src.persistence_manager import PersistenceManager

# 创建Flask应用
app = Flask(__name__)
CORS(app)

# 初始化服务
llm_service = LLMService()
doc_manager = DocumentManager(vector_model, llm_service)
persistence = PersistenceManager()

# 在启动时加载已有文档
def load_existing_documents():
    """加载数据库中已有的文档"""
    try:
        documents = persistence.list_documents()
        for doc_info in documents:
            doc_id = doc_info['doc_id']
            document = persistence.load_document(doc_id)
            if document:
                doc_manager.documents[doc_id] = document
                if doc_id >= doc_manager.next_doc_id:
                    doc_manager.next_doc_id = doc_id + 1
        
        logger.info(f"Loaded {len(documents)} existing documents")
    except Exception as e:
        logger.error(f"Failed to load existing documents: {str(e)}")

# 错误处理装饰器
def handle_errors(f):
    def wrapper(*args, **kwargs):
        try:
            return f(*args, **kwargs)
        except Exception as e:
            logger.error(f"Error in {f.__name__}: {str(e)}")
            logger.error(traceback.format_exc())
            return jsonify({
                "error": str(e),
                "success": False
            }), 500
    wrapper.__name__ = f.__name__
    return wrapper

@app.route('/health', methods=['GET'])
def health_check():
    """健康检查端点"""
    return jsonify({
        "status": "healthy",
        "version": "0.1.0",
        "services": {
            "document_manager": True,
            "persistence": True,
            "llm_service": True
        }
    })

@app.route('/documents', methods=['POST'])
@handle_errors
def create_document():
    """创建新文档"""
    data = request.json
    if not data or 'title' not in data:
        return jsonify({"error": "Title is required"}), 400
    
    title = data.get('title', '').strip()
    initial_content = data.get('content', '').strip()
    
    if not title:
        return jsonify({"error": "Title cannot be empty"}), 400
    
    # 创建文档
    doc_id = doc_manager.create_document(title, initial_content)
    
    # 保存到数据库
    document = doc_manager.get_document(doc_id)
    if document and persistence.save_document(document):
        return jsonify({
            "doc_id": doc_id,
            "title": title,
            "success": True
        }), 201
    else:
        return jsonify({
            "error": "Failed to save document",
            "success": False
        }), 500

@app.route('/documents', methods=['GET'])
@handle_errors
def list_documents():
    """列出所有文档"""
    limit = int(request.args.get('limit', 100))
    offset = int(request.args.get('offset', 0))
    
    documents = persistence.list_documents(limit, offset)
    
    return jsonify({
        "documents": documents,
        "total": len(documents),
        "success": True
    })

@app.route('/documents/<int:doc_id>', methods=['GET'])
@handle_errors
def get_document(doc_id):
    """获取文档详情"""
    include_vectors = request.args.get('include_vectors', 'false').lower() == 'true'
    
    # 先尝试从内存加载
    document = doc_manager.get_document(doc_id)
    
    # 如果内存中没有，从数据库加载
    if not document:
        document = persistence.load_document(doc_id)
        if document:
            doc_manager.documents[doc_id] = document
    
    if not document:
        return jsonify({"error": "Document not found"}), 404
    
    # 构建响应
    doc_dict = document.to_dict(include_vectors=include_vectors)
    doc_dict["success"] = True
    
    return jsonify(doc_dict)

@app.route('/documents/<int:doc_id>', methods=['PUT'])
@handle_errors
def update_document(doc_id):
    """更新文档信息"""
    data = request.json
    if not data:
        return jsonify({"error": "Request body is required"}), 400
    
    document = doc_manager.get_document(doc_id)
    if not document:
        document = persistence.load_document(doc_id)
        if document:
            doc_manager.documents[doc_id] = document
    
    if not document:
        return jsonify({"error": "Document not found"}), 404
    
    # 更新标题
    if 'title' in data:
        document.title = data['title'].strip()
    
    # 更新元数据
    if 'metadata' in data:
        document.metadata.update(data['metadata'])
    
    document.updated_at = time.time()
    
    # 保存更改
    if persistence.save_document(document):
        return jsonify({
            "doc_id": doc_id,
            "title": document.title,
            "updated_at": document.updated_at,
            "success": True
        })
    else:
        return jsonify({
            "error": "Failed to update document",
            "success": False
        }), 500

@app.route('/documents/<int:doc_id>', methods=['DELETE'])
@handle_errors
def delete_document(doc_id):
    """删除文档"""
    # 从内存中删除
    doc_manager.delete_document(doc_id)
    
    # 从数据库删除
    if persistence.delete_document(doc_id):
        return jsonify({
            "doc_id": doc_id,
            "success": True
        })
    else:
        return jsonify({
            "error": "Failed to delete document",
            "success": False
        }), 500

@app.route('/documents/<int:doc_id>/nodes', methods=['POST'])
@handle_errors
def add_node(doc_id):
    """添加新节点"""
    data = request.json
    if not data or 'parent_coord' not in data or 'content' not in data:
        return jsonify({"error": "parent_coord and content are required"}), 400
    
    try:
        parent_coord = int(data['parent_coord'])
        content = data['content'].strip()
        position = data.get('position')
        
        if not content:
            return jsonify({"error": "Content cannot be empty"}), 400
        
        if position is not None:
            position = int(position)
        
        # 添加节点
        node_coord = doc_manager.add_node(doc_id, parent_coord, content, position)
        
        # 保存到数据库
        document = doc_manager.get_document(doc_id)
        if document and persistence.save_document(document):
            return jsonify({
                "node_id": node_coord,
                "doc_id": doc_id,
                "success": True
            }), 201
        else:
            return jsonify({
                "error": "Failed to save node",
                "success": False
            }), 500
            
    except ValueError as e:
        return jsonify({"error": f"Invalid coordinate or position: {str(e)}"}), 400

@app.route('/documents/<int:doc_id>/nodes/<int:node_id>', methods=['PUT'])
@handle_errors
def update_node(doc_id, node_id):
    """更新节点内容"""
    data = request.json
    if not data or 'content' not in data:
        return jsonify({"error": "content is required"}), 400
    
    content = data['content'].strip()
    if not content:
        return jsonify({"error": "Content cannot be empty"}), 400
    
    # 更新节点
    if doc_manager.update_node_content(doc_id, node_id, content):
        # 保存到数据库
        document = doc_manager.get_document(doc_id)
        if document and persistence.save_document(document):
            return jsonify({
                "node_id": node_id,
                "doc_id": doc_id,
                "content": content,
                "success": True
            })
        else:
            return jsonify({
                "error": "Failed to save changes",
                "success": False
            }), 500
    else:
        return jsonify({
            "error": "Failed to update node",
            "success": False
        }), 404

@app.route('/documents/<int:doc_id>/nodes/<int:node_id>', methods=['DELETE'])
@handle_errors
def delete_node(doc_id, node_id):
    """删除节点"""
    if doc_manager.delete_node(doc_id, node_id):
        # 保存到数据库
        document = doc_manager.get_document(doc_id)
        if document and persistence.save_document(document):
            return jsonify({
                "node_id": node_id,
                "doc_id": doc_id,
                "success": True
            })
        else:
            return jsonify({
                "error": "Failed to save changes",
                "success": False
            }), 500
    else:
        return jsonify({
            "error": "Failed to delete node",
            "success": False
        }), 404

@app.route('/documents/<int:doc_id>/nodes/<int:node_id>/move', methods=['POST'])
@handle_errors
def move_node(doc_id, node_id):
    """移动节点"""
    data = request.json
    if not data or 'new_parent_coord' not in data:
        return jsonify({"error": "new_parent_coord is required"}), 400
    
    try:
        new_parent_coord = int(data['new_parent_coord'])
        position = data.get('position')
        
        if position is not None:
            position = int(position)
        
        # 移动节点
        if doc_manager.move_node(doc_id, node_id, new_parent_coord, position):
            # 保存到数据库
            document = doc_manager.get_document(doc_id)
            if document and persistence.save_document(document):
                return jsonify({
                    "node_id": node_id,
                    "doc_id": doc_id,
                    "new_parent_coord": new_parent_coord,
                    "success": True
                })
            else:
                return jsonify({
                    "error": "Failed to save changes",
                    "success": False
                }), 500
        else:
            return jsonify({
                "error": "Failed to move node",
                "success": False
            }), 400
            
    except ValueError as e:
        return jsonify({"error": f"Invalid coordinate: {str(e)}"}), 400

@app.route('/documents/<int:doc_id>/optimize', methods=['POST'])
@handle_errors
def optimize_document(doc_id):
    """优化文档结构"""
    # 确保文档在内存中
    document = doc_manager.get_document(doc_id)
    if not document:
        document = persistence.load_document(doc_id)
        if document:
            doc_manager.documents[doc_id] = document
    
    if not document:
        return jsonify({"error": "Document not found"}), 404
    
    # 执行优化
    result = doc_manager.optimize_document(doc_id)
    
    # 如果优化成功，保存到数据库
    if result.get('success', False):
        document = doc_manager.get_document(doc_id)
        if document:
            persistence.save_document(document)
    
    return jsonify(result)

@app.route('/search', methods=['GET'])
@handle_errors
def search_content():
    """搜索内容"""
    query = request.args.get('q', '').strip()
    doc_id = request.args.get('doc_id')
    limit = int(request.args.get('limit', 50))
    
    if not query:
        return jsonify({"error": "Query parameter 'q' is required"}), 400
    
    try:
        if doc_id:
            doc_id = int(doc_id)
            doc_ids = [doc_id]
        else:
            doc_ids = None
        
        # 使用文档管理器搜索
        results = doc_manager.search_documents(query, doc_ids)
        
        # 限制结果数量
        if len(results) > limit:
            results = results[:limit]
        
        return jsonify({
            "query": query,
            "results": results,
            "total": len(results),
            "success": True
        })
        
    except ValueError:
        return jsonify({"error": "Invalid doc_id"}), 400

@app.route('/documents/<int:doc_id>/statistics', methods=['GET'])
@handle_errors
def get_document_statistics(doc_id):
    """获取文档统计信息"""
    document = doc_manager.get_document(doc_id)
    if not document:
        document = persistence.load_document(doc_id)
        if document:
            doc_manager.documents[doc_id] = document
    
    if not document:
        return jsonify({"error": "Document not found"}), 404
    
    stats = document.get_statistics()
    validation = document.validate_structure()
    
    return jsonify({
        "statistics": stats,
        "validation": validation,
        "success": True
    })

@app.route('/statistics', methods=['GET'])
@handle_errors
def get_system_statistics():
    """获取系统统计信息"""
    # 文档管理器统计
    manager_stats = doc_manager.get_statistics()
    
    # 数据库统计
    db_stats = persistence.get_database_statistics()
    
    return jsonify({
        "manager_statistics": manager_stats,
        "database_statistics": db_stats,
        "success": True
    })

@app.route('/backup', methods=['POST'])
@handle_errors
def backup_database():
    """备份数据库"""
    data = request.json or {}
    backup_path = data.get('backup_path', f'growdoc_backup_{int(time.time())}.db')
    
    if persistence.backup_database(backup_path):
        return jsonify({
            "backup_path": backup_path,
            "success": True
        })
    else:
        return jsonify({
            "error": "Failed to create backup",
            "success": False
        }), 500

# 错误处理
@app.errorhandler(404)
def not_found(error):
    return jsonify({
        "error": "Endpoint not found",
        "success": False
    }), 404

@app.errorhandler(405)
def method_not_allowed(error):
    return jsonify({
        "error": "Method not allowed",
        "success": False
    }), 405

@app.errorhandler(500)
def internal_error(error):
    return jsonify({
        "error": "Internal server error",
        "success": False
    }), 500

if __name__ == '__main__':
    import time
    
    # 加载已有文档
    load_existing_documents()
    
    logger.info("Starting GrowDoc API server...")
    app.run(debug=True, host='0.0.0.0', port=5000)