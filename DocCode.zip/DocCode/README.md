# GrowDoc 最小原型验证版

一个基于64位坐标系统和LLM驱动优化的分层文档管理系统。

## 🚀 快速开始

### 环境要求

- Python 3.8+
- pip (Python包管理器)

### 安装步骤

1. **克隆或下载项目**
   ```bash
   # 如果有git仓库
   git clone <repository-url>
   cd DocCode
   ```

2. **安装依赖**
   ```bash
   pip install -r requirements.txt
   ```

3. **启动API服务**
   ```bash
   python api.py
   ```

4. **验证服务**
   打开浏览器访问: http://localhost:5000/health

## 📁 项目结构

```
DocCode/
├── src/                      # 核心源代码
│   ├── __init__.py
│   ├── coordinate_system.py  # 64位坐标系统
│   ├── document_node.py      # 文档节点
│   ├── document.py           # 文档类
│   ├── llm_service.py        # LLM优化服务
│   ├── document_manager.py   # 文档管理器
│   └── persistence_manager.py # 持久化管理
├── tests/                    # 测试代码
│   ├── test_coordinate_system.py
│   ├── test_document_node.py
│   ├── test_document_manager.py
│   └── integration_test.py
├── api.py                    # Flask API服务
├── run_tests.py              # 测试运行脚本
├── requirements.txt          # 依赖清单
└── README.md                 # 本文档
```

## 🔧 核心功能

### 1. 64位坐标系统

- **分层坐标**: 支持最多6层嵌套结构
- **唯一标识**: 每个节点都有唯一的64位坐标
- **层级管理**: 自动处理父子关系和兄弟排序

### 2. 文档节点管理

- **内容管理**: 支持文本内容的增删改查
- **层级结构**: 树形结构的文档组织
- **词向量**: 自动生成内容的向量表示

### 3. LLM驱动优化

- **结构分析**: 自动分析文档结构问题
- **优化建议**: 提供重组、合并、拆分等建议
- **智能重构**: 基于内容相似性的结构优化

### 4. 持久化存储

- **SQLite数据库**: 轻量级本地存储
- **完整性保证**: 事务支持和数据验证
- **高效查询**: 索引优化的快速检索

## 🌐 API接口

### 文档管理

- `POST /documents` - 创建文档
- `GET /documents` - 列出所有文档
- `GET /documents/{id}` - 获取文档详情
- `PUT /documents/{id}` - 更新文档
- `DELETE /documents/{id}` - 删除文档

### 节点操作

- `POST /documents/{id}/nodes` - 添加节点
- `PUT /documents/{id}/nodes/{node_id}` - 更新节点
- `DELETE /documents/{id}/nodes/{node_id}` - 删除节点
- `POST /documents/{id}/nodes/{node_id}/move` - 移动节点

### 优化和分析

- `POST /documents/{id}/optimize` - 优化文档结构
- `GET /documents/{id}/statistics` - 获取文档统计
- `GET /search` - 搜索内容

### 系统管理

- `GET /health` - 健康检查
- `GET /statistics` - 系统统计
- `POST /backup` - 数据备份

## 📊 使用示例

### 1. 创建文档

```bash
curl -X POST http://localhost:5000/documents \
  -H "Content-Type: application/json" \
  -d '{"title":"我的文档","content":"这是根节点内容"}'
```

### 2. 添加章节

```bash
curl -X POST http://localhost:5000/documents/1/nodes \
  -H "Content-Type: application/json" \
  -d '{"parent_coord":1152921504606846976,"content":"第一章"}'
```

### 3. 搜索内容

```bash
curl "http://localhost:5000/search?q=章节&doc_id=1"
```

### 4. 优化结构

```bash
curl -X POST http://localhost:5000/documents/1/optimize
```

## 🧪 测试

### 运行所有测试

```bash
python run_tests.py
```

### 只运行单元测试

```bash
python run_tests.py --unit-only
```

### 只运行集成测试

```bash
python run_tests.py --integration-only
```

### 手动运行单元测试

```bash
python -m pytest tests/ -v
```

### 手动运行集成测试

```bash
# 启动API服务 (终端1)
python api.py

# 运行集成测试 (终端2)
python tests/integration_test.py
```

## 🔧 配置说明

### 环境变量

- `GROWDOC_DB_PATH`: 数据库文件路径 (默认: growdoc.db)
- `GROWDOC_LOG_LEVEL`: 日志级别 (默认: INFO)

### 可选依赖

- **sentence-transformers**: 词向量模型 (如不安装会使用模拟模型)
- **gunicorn**: 生产环境WSGI服务器

## 🚀 部署

### 开发环境

```bash
python api.py
```

### 生产环境 (使用Gunicorn)

```bash
pip install gunicorn
gunicorn -w 4 -b 0.0.0.0:5000 api:app
```

### 生产环境 (使用Waitress，Windows推荐)

```bash
pip install waitress
waitress-serve --host=0.0.0.0 --port=5000 api:app
```

## 📈 性能特性

- **内存效率**: 按需加载文档，支持大量文档
- **查询优化**: 数据库索引优化的快速检索
- **并发支持**: 线程安全的数据访问
- **可扩展性**: 模块化设计，易于扩展功能

## 🔍 故障排除

### 常见问题

1. **导入错误**
   ```bash
   # 确保在项目根目录运行
   cd DocCode
   python api.py
   ```

2. **端口占用**
   ```bash
   # 检查端口5000是否被占用
   netstat -an | findstr :5000
   ```

3. **数据库锁定**
   ```bash
   # 删除数据库文件重新开始
   del growdoc.db
   ```

4. **词向量模型下载慢**
   ```bash
   # 设置镜像源
   pip install sentence-transformers -i https://pypi.tuna.tsinghua.edu.cn/simple
   ```

### 日志查看

API服务启动后会在控制台输出详细日志，包括：
- 请求处理日志
- 错误信息
- 性能统计

## 🤝 开发指南

### 代码结构

- **coordinate_system.py**: 坐标系统核心算法
- **document_node.py**: 节点数据结构和操作
- **document.py**: 文档级别的管理功能
- **document_manager.py**: 多文档管理和协调
- **persistence_manager.py**: 数据持久化逻辑
- **llm_service.py**: LLM集成和优化逻辑

### 扩展建议

1. **增加更多LLM提供商**: 支持OpenAI、Claude等
2. **实现版本控制**: 文档变更历史跟踪
3. **添加用户权限**: 多用户和权限管理
4. **Web界面**: 构建前端用户界面
5. **分布式存储**: 支持多节点部署

## 📝 版本历史

- **v0.1.0**: 初始原型版本
  - 基础坐标系统
  - 文档CRUD操作
  - 简单LLM优化
  - SQLite持久化

## 📄 许可证

本项目为原型验证版本，仅供学习和测试使用。

---

**注意**: 这是一个最小原型验证版本，主要用于验证核心概念的可行性。在生产环境使用前，建议进行充分的安全审计和性能测试。