"""
集成测试脚本
测试整个GrowDoc系统的完整功能
"""
import requests
import json
import time
import logging
from typing import Dict, Any, List

# 设置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class GrowDocIntegrationTest:
    """GrowDoc集成测试类"""
    
    def __init__(self, base_url: str = "http://localhost:5000"):
        """
        初始化测试
        
        Args:
            base_url: API服务器基础URL
        """
        self.base_url = base_url
        self.session = requests.Session()
        self.created_docs = []  # 跟踪创建的文档用于清理
        
    def test_health_check(self) -> bool:
        """测试健康检查端点"""
        try:
            logger.info("Testing health check...")
            response = self.session.get(f"{self.base_url}/health")
            
            if response.status_code != 200:
                logger.error(f"Health check failed with status {response.status_code}")
                return False
                
            data = response.json()
            
            if not data.get("status") == "healthy":
                logger.error("Health check returned unhealthy status")
                return False
                
            logger.info("✓ Health check passed")
            return True
            
        except Exception as e:
            logger.error(f"Health check error: {str(e)}")
            return False
    
    def test_document_lifecycle(self) -> bool:
        """测试文档完整生命周期"""
        try:
            logger.info("Testing document lifecycle...")
            
            # 1. 创建文档
            doc_data = {
                "title": "Integration Test Document",
                "content": "This is a test document for integration testing"
            }
            
            response = self.session.post(f"{self.base_url}/documents", json=doc_data)
            if response.status_code != 201:
                logger.error(f"Document creation failed: {response.status_code}")
                return False
                
            doc_id = response.json()["doc_id"]
            self.created_docs.append(doc_id)
            logger.info(f"✓ Document created with ID: {doc_id}")
            
            # 2. 获取文档
            response = self.session.get(f"{self.base_url}/documents/{doc_id}")
            if response.status_code != 200:
                logger.error(f"Document retrieval failed: {response.status_code}")
                return False
                
            doc_data = response.json()
            if doc_data["title"] != "Integration Test Document":
                logger.error("Document title mismatch")
                return False
                
            root_id = doc_data["structure"]["node_id"]
            logger.info("✓ Document retrieved successfully")
            
            # 3. 添加节点
            nodes_to_add = [
                {"parent_coord": root_id, "content": "Chapter 1: Introduction"},
                {"parent_coord": root_id, "content": "Chapter 2: Main Content"},
                {"parent_coord": root_id, "content": "Chapter 3: Conclusion"},
            ]
            
            added_nodes = []
            for i, node_data in enumerate(nodes_to_add):
                response = self.session.post(f"{self.base_url}/documents/{doc_id}/nodes", json=node_data)
                if response.status_code != 201:
                    logger.error(f"Node creation failed for node {i}: {response.status_code}")
                    return False
                    
                node_id = response.json()["node_id"]
                added_nodes.append(node_id)
                
            logger.info(f"✓ Added {len(added_nodes)} nodes")
            
            # 4. 添加子节点
            subnode_data = {
                "parent_coord": added_nodes[0],  # Chapter 1的子节点
                "content": "Section 1.1: Background"
            }
            
            response = self.session.post(f"{self.base_url}/documents/{doc_id}/nodes", json=subnode_data)
            if response.status_code != 201:
                logger.error(f"Subnode creation failed: {response.status_code}")
                return False
                
            subnode_id = response.json()["node_id"]
            logger.info("✓ Subnode created successfully")
            
            # 5. 更新节点内容
            update_data = {"content": "Chapter 1: Updated Introduction"}
            response = self.session.put(f"{self.base_url}/documents/{doc_id}/nodes/{added_nodes[0]}", json=update_data)
            if response.status_code != 200:
                logger.error(f"Node update failed: {response.status_code}")
                return False
                
            logger.info("✓ Node updated successfully")
            
            # 6. 获取更新后的文档结构
            response = self.session.get(f"{self.base_url}/documents/{doc_id}")
            if response.status_code != 200:
                logger.error("Failed to retrieve updated document")
                return False
                
            updated_doc = response.json()
            if updated_doc["node_count"] != 5:  # root + 3 chapters + 1 section
                logger.error(f"Unexpected node count: {updated_doc['node_count']}")
                return False
                
            logger.info("✓ Document structure verified")
            
            # 7. 移动节点
            move_data = {"new_parent_coord": added_nodes[1]}  # 移动到Chapter 2
            response = self.session.post(f"{self.base_url}/documents/{doc_id}/nodes/{subnode_id}/move", json=move_data)
            if response.status_code != 200:
                logger.error(f"Node move failed: {response.status_code}")
                return False
                
            logger.info("✓ Node moved successfully")
            
            # 8. 搜索内容
            response = self.session.get(f"{self.base_url}/search", params={"q": "Introduction", "doc_id": doc_id})
            if response.status_code != 200:
                logger.error(f"Search failed: {response.status_code}")
                return False
                
            search_results = response.json()
            if len(search_results["results"]) == 0:
                logger.error("Search returned no results")
                return False
                
            logger.info("✓ Search functionality working")
            
            # 9. 获取统计信息
            response = self.session.get(f"{self.base_url}/documents/{doc_id}/statistics")
            if response.status_code != 200:
                logger.error(f"Statistics retrieval failed: {response.status_code}")
                return False
                
            stats = response.json()
            if not stats.get("success"):
                logger.error("Statistics request was not successful")
                return False
                
            logger.info("✓ Statistics retrieved successfully")
            
            # 10. 触发优化
            response = self.session.post(f"{self.base_url}/documents/{doc_id}/optimize")
            if response.status_code != 200:
                logger.error(f"Optimization failed: {response.status_code}")
                return False
                
            opt_result = response.json()
            if not opt_result.get("success"):
                logger.error("Optimization was not successful")
                return False
                
            logger.info("✓ Document optimization completed")
            
            # 11. 删除节点
            response = self.session.delete(f"{self.base_url}/documents/{doc_id}/nodes/{subnode_id}")
            if response.status_code != 200:
                logger.error(f"Node deletion failed: {response.status_code}")
                return False
                
            logger.info("✓ Node deleted successfully")
            
            # 12. 更新文档元数据
            update_doc_data = {
                "title": "Updated Integration Test Document",
                "metadata": {"test": True, "version": "1.1"}
            }
            response = self.session.put(f"{self.base_url}/documents/{doc_id}", json=update_doc_data)
            if response.status_code != 200:
                logger.error(f"Document update failed: {response.status_code}")
                return False
                
            logger.info("✓ Document metadata updated")
            
            logger.info("✓ Complete document lifecycle test passed")
            return True
            
        except Exception as e:
            logger.error(f"Document lifecycle test error: {str(e)}")
            return False
    
    def test_multiple_documents(self) -> bool:
        """测试多文档操作"""
        try:
            logger.info("Testing multiple documents...")
            
            # 创建多个文档
            doc_titles = [
                "Python Programming Guide",
                "Web Development Basics", 
                "Database Design Principles"
            ]
            
            doc_ids = []
            for title in doc_titles:
                doc_data = {"title": title, "content": f"Content for {title}"}
                response = self.session.post(f"{self.base_url}/documents", json=doc_data)
                
                if response.status_code != 201:
                    logger.error(f"Failed to create document: {title}")
                    return False
                    
                doc_id = response.json()["doc_id"]
                doc_ids.append(doc_id)
                self.created_docs.append(doc_id)
            
            logger.info(f"✓ Created {len(doc_ids)} documents")
            
            # 为每个文档添加内容
            for i, doc_id in enumerate(doc_ids):
                # 获取根节点
                response = self.session.get(f"{self.base_url}/documents/{doc_id}")
                root_id = response.json()["structure"]["node_id"]
                
                # 添加章节
                for j in range(3):
                    chapter_data = {
                        "parent_coord": root_id,
                        "content": f"Chapter {j+1} of {doc_titles[i]}"
                    }
                    self.session.post(f"{self.base_url}/documents/{doc_id}/nodes", json=chapter_data)
            
            logger.info("✓ Added content to all documents")
            
            # 列出所有文档
            response = self.session.get(f"{self.base_url}/documents")
            if response.status_code != 200:
                logger.error("Failed to list documents")
                return False
                
            doc_list = response.json()
            if len(doc_list["documents"]) < len(doc_ids):
                logger.error("Document list incomplete")
                return False
                
            logger.info("✓ Document listing working")
            
            # 跨文档搜索
            response = self.session.get(f"{self.base_url}/search", params={"q": "Programming"})
            if response.status_code != 200:
                logger.error("Cross-document search failed")
                return False
                
            search_results = response.json()
            if len(search_results["results"]) == 0:
                logger.error("Cross-document search returned no results")
                return False
                
            logger.info("✓ Cross-document search working")
            
            # 获取系统统计
            response = self.session.get(f"{self.base_url}/statistics")
            if response.status_code != 200:
                logger.error("System statistics failed")
                return False
                
            stats = response.json()
            if stats["manager_statistics"]["total_documents"] < len(doc_ids):
                logger.error("System statistics show incorrect document count")
                return False
                
            logger.info("✓ System statistics working")
            
            logger.info("✓ Multiple documents test passed")
            return True
            
        except Exception as e:
            logger.error(f"Multiple documents test error: {str(e)}")
            return False
    
    def test_error_handling(self) -> bool:
        """测试错误处理"""
        try:
            logger.info("Testing error handling...")
            
            # 测试无效端点
            response = self.session.get(f"{self.base_url}/invalid-endpoint")
            if response.status_code != 404:
                logger.error("Invalid endpoint should return 404")
                return False
                
            # 测试无效方法
            response = self.session.patch(f"{self.base_url}/documents")
            if response.status_code != 405:
                logger.error("Invalid method should return 405")
                return False
                
            # 测试无效文档ID
            response = self.session.get(f"{self.base_url}/documents/99999")
            if response.status_code != 404:
                logger.error("Invalid document ID should return 404")
                return False
                
            # 测试无效请求数据
            response = self.session.post(f"{self.base_url}/documents", json={})
            if response.status_code != 400:
                logger.error("Empty document data should return 400")
                return False
                
            # 测试空标题
            response = self.session.post(f"{self.base_url}/documents", json={"title": ""})
            if response.status_code != 400:
                logger.error("Empty title should return 400")
                return False
                
            logger.info("✓ Error handling test passed")
            return True
            
        except Exception as e:
            logger.error(f"Error handling test error: {str(e)}")
            return False
    
    def test_performance(self) -> bool:
        """测试基本性能"""
        try:
            logger.info("Testing basic performance...")
            
            # 创建文档
            doc_data = {"title": "Performance Test Document"}
            response = self.session.post(f"{self.base_url}/documents", json=doc_data)
            doc_id = response.json()["doc_id"]
            self.created_docs.append(doc_id)
            
            # 获取根节点
            response = self.session.get(f"{self.base_url}/documents/{doc_id}")
            root_id = response.json()["structure"]["node_id"]
            
            # 批量添加节点并测量时间
            start_time = time.time()
            node_count = 50
            
            for i in range(node_count):
                node_data = {
                    "parent_coord": root_id,
                    "content": f"Performance test node {i} with some content to make it realistic"
                }
                response = self.session.post(f"{self.base_url}/documents/{doc_id}/nodes", json=node_data)
                if response.status_code != 201:
                    logger.error(f"Failed to create node {i}")
                    return False
            
            end_time = time.time()
            total_time = end_time - start_time
            avg_time = total_time / node_count
            
            logger.info(f"✓ Created {node_count} nodes in {total_time:.2f}s (avg: {avg_time:.3f}s per node)")
            
            # 测试搜索性能
            start_time = time.time()
            response = self.session.get(f"{self.base_url}/search", params={"q": "test", "doc_id": doc_id})
            search_time = time.time() - start_time
            
            if response.status_code != 200:
                logger.error("Search performance test failed")
                return False
                
            logger.info(f"✓ Search completed in {search_time:.3f}s")
            
            # 测试文档检索性能
            start_time = time.time()
            response = self.session.get(f"{self.base_url}/documents/{doc_id}")
            retrieval_time = time.time() - start_time
            
            logger.info(f"✓ Document retrieval completed in {retrieval_time:.3f}s")
            
            # 性能警告阈值
            if avg_time > 1.0:
                logger.warning(f"Node creation is slow: {avg_time:.3f}s per node")
            if search_time > 2.0:
                logger.warning(f"Search is slow: {search_time:.3f}s")
            if retrieval_time > 1.0:
                logger.warning(f"Document retrieval is slow: {retrieval_time:.3f}s")
            
            logger.info("✓ Performance test completed")
            return True
            
        except Exception as e:
            logger.error(f"Performance test error: {str(e)}")
            return False
    
    def test_data_integrity(self) -> bool:
        """测试数据完整性"""
        try:
            logger.info("Testing data integrity...")
            
            # 创建文档
            doc_data = {"title": "Data Integrity Test"}
            response = self.session.post(f"{self.base_url}/documents", json=doc_data)
            doc_id = response.json()["doc_id"]
            self.created_docs.append(doc_id)
            
            # 构建复杂结构
            response = self.session.get(f"{self.base_url}/documents/{doc_id}")
            root_id = response.json()["structure"]["node_id"]
            
            # 创建多层结构
            chapter1_data = {"parent_coord": root_id, "content": "Chapter 1"}
            response = self.session.post(f"{self.base_url}/documents/{doc_id}/nodes", json=chapter1_data)
            chapter1_id = response.json()["node_id"]
            
            section1_data = {"parent_coord": chapter1_id, "content": "Section 1.1"}
            response = self.session.post(f"{self.base_url}/documents/{doc_id}/nodes", json=section1_data)
            section1_id = response.json()["node_id"]
            
            subsection1_data = {"parent_coord": section1_id, "content": "Subsection 1.1.1"}
            response = self.session.post(f"{self.base_url}/documents/{doc_id}/nodes", json=subsection1_data)
            
            # 验证结构完整性
            response = self.session.get(f"{self.base_url}/documents/{doc_id}")
            doc_structure = response.json()
            
            if doc_structure["node_count"] != 4:  # root + chapter + section + subsection
                logger.error(f"Unexpected node count: {doc_structure['node_count']}")
                return False
                
            # 验证层级结构
            structure = doc_structure["structure"]
            if len(structure["children"]) != 1:
                logger.error("Root should have exactly one child")
                return False
                
            chapter = structure["children"][0]
            if chapter["content"] != "Chapter 1":
                logger.error("Chapter content mismatch")
                return False
                
            if len(chapter["children"]) != 1:
                logger.error("Chapter should have exactly one child")
                return False
                
            logger.info("✓ Data structure integrity verified")
            
            # 测试统计一致性
            response = self.session.get(f"{self.base_url}/documents/{doc_id}/statistics")
            stats = response.json()
            
            if stats["statistics"]["node_count"] != doc_structure["node_count"]:
                logger.error("Statistics node count mismatch")
                return False
                
            # 验证坐标系统完整性
            if not stats["validation"]["valid"]:
                logger.error("Document structure validation failed")
                logger.error(f"Issues: {stats['validation']['issues']}")
                return False
                
            logger.info("✓ Data integrity test passed")
            return True
            
        except Exception as e:
            logger.error(f"Data integrity test error: {str(e)}")
            return False
    
    def cleanup(self):
        """清理测试数据"""
        logger.info("Cleaning up test data...")
        
        for doc_id in self.created_docs:
            try:
                response = self.session.delete(f"{self.base_url}/documents/{doc_id}")
                if response.status_code == 200:
                    logger.info(f"✓ Deleted document {doc_id}")
                else:
                    logger.warning(f"Failed to delete document {doc_id}")
            except Exception as e:
                logger.warning(f"Error deleting document {doc_id}: {str(e)}")
        
        self.created_docs.clear()
    
    def run_all_tests(self) -> bool:
        """运行所有测试"""
        logger.info("Starting GrowDoc integration tests...")
        
        tests = [
            ("Health Check", self.test_health_check),
            ("Document Lifecycle", self.test_document_lifecycle),
            ("Multiple Documents", self.test_multiple_documents),
            ("Error Handling", self.test_error_handling),
            ("Performance", self.test_performance),
            ("Data Integrity", self.test_data_integrity),
        ]
        
        passed = 0
        failed = 0
        
        for test_name, test_func in tests:
            logger.info(f"\n{'='*50}")
            logger.info(f"Running: {test_name}")
            logger.info(f"{'='*50}")
            
            try:
                if test_func():
                    logger.info(f"✓ {test_name} PASSED")
                    passed += 1
                else:
                    logger.error(f"✗ {test_name} FAILED")
                    failed += 1
            except Exception as e:
                logger.error(f"✗ {test_name} ERROR: {str(e)}")
                failed += 1
        
        # 清理
        self.cleanup()
        
        # 总结
        logger.info(f"\n{'='*50}")
        logger.info("TEST SUMMARY")
        logger.info(f"{'='*50}")
        logger.info(f"Total tests: {passed + failed}")
        logger.info(f"Passed: {passed}")
        logger.info(f"Failed: {failed}")
        
        if failed == 0:
            logger.info("🎉 ALL TESTS PASSED!")
            return True
        else:
            logger.error(f"❌ {failed} TEST(S) FAILED")
            return False


def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description="GrowDoc Integration Tests")
    parser.add_argument("--url", default="http://localhost:5000", 
                       help="API server URL (default: http://localhost:5000)")
    parser.add_argument("--wait", type=int, default=5,
                       help="Wait time for server startup (default: 5 seconds)")
    
    args = parser.parse_args()
    
    # 等待服务器启动
    logger.info(f"Waiting {args.wait} seconds for server to start...")
    time.sleep(args.wait)
    
    # 运行测试
    tester = GrowDocIntegrationTest(args.url)
    success = tester.run_all_tests()
    
    exit(0 if success else 1)


if __name__ == "__main__":
    main()