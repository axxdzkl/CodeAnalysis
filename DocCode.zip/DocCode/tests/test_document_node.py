"""
文档节点单元测试
"""
import unittest
import numpy as np
from src.document_node import DocumentNode
from src.coordinate_system import CoordinateSystem


class TestDocumentNode(unittest.TestCase):
    """测试文档节点类"""
    
    def setUp(self):
        """设置测试数据"""
        # 创建测试节点
        self.root_coord = CoordinateSystem.create_coordinate(1, [0])
        self.root = DocumentNode(self.root_coord, "Root Node", 0)
        
        self.child1_coord = CoordinateSystem.create_coordinate(2, [0, 0])
        self.child1 = DocumentNode(self.child1_coord, "Child 1", 1)
        
        self.child2_coord = CoordinateSystem.create_coordinate(2, [0, 1])
        self.child2 = DocumentNode(self.child2_coord, "Child 2", 1)
        
        self.grandchild_coord = CoordinateSystem.create_coordinate(3, [0, 0, 0])
        self.grandchild = DocumentNode(self.grandchild_coord, "Grandchild", 2)
    
    def test_node_creation(self):
        """测试节点创建"""
        self.assertEqual(self.root.node_id, self.root_coord)
        self.assertEqual(self.root.content, "Root Node")
        self.assertEqual(self.root.level, 0)
        self.assertIsNone(self.root.vector)
        self.assertEqual(len(self.root.children), 0)
        self.assertIsNone(self.root.parent)
        self.assertIsInstance(self.root.metadata, dict)
    
    def test_add_child(self):
        """测试添加子节点"""
        # 添加子节点
        self.root.add_child(self.child1)
        
        # 验证父子关系
        self.assertIn(self.child1, self.root.children)
        self.assertEqual(self.child1.parent, self.root)
        self.assertEqual(len(self.root.children), 1)
        
        # 添加第二个子节点
        self.root.add_child(self.child2)
        self.assertEqual(len(self.root.children), 2)
        
        # 重复添加应该不会增加数量
        self.root.add_child(self.child1)
        self.assertEqual(len(self.root.children), 2)
    
    def test_remove_child(self):
        """测试移除子节点"""
        # 先添加子节点
        self.root.add_child(self.child1)
        self.root.add_child(self.child2)
        self.assertEqual(len(self.root.children), 2)
        
        # 移除一个子节点
        self.root.remove_child(self.child1)
        self.assertNotIn(self.child1, self.root.children)
        self.assertIsNone(self.child1.parent)
        self.assertEqual(len(self.root.children), 1)
        
        # 移除不存在的子节点不应该报错
        self.root.remove_child(self.child1)
        self.assertEqual(len(self.root.children), 1)
    
    def test_get_siblings(self):
        """测试获取兄弟节点"""
        # 根节点没有兄弟节点
        siblings = self.root.get_siblings()
        self.assertEqual(len(siblings), 0)
        
        # 添加子节点
        self.root.add_child(self.child1)
        self.root.add_child(self.child2)
        
        # 获取兄弟节点
        child1_siblings = self.child1.get_siblings()
        self.assertEqual(len(child1_siblings), 1)
        self.assertIn(self.child2, child1_siblings)
        self.assertNotIn(self.child1, child1_siblings)
        
        child2_siblings = self.child2.get_siblings()
        self.assertEqual(len(child2_siblings), 1)
        self.assertIn(self.child1, child2_siblings)
    
    def test_get_descendants(self):
        """测试获取后代节点"""
        # 构建层级结构
        self.root.add_child(self.child1)
        self.child1.add_child(self.grandchild)
        
        # 获取根节点的所有后代
        descendants = self.root.get_descendants()
        self.assertEqual(len(descendants), 2)
        self.assertIn(self.child1, descendants)
        self.assertIn(self.grandchild, descendants)
        
        # 获取中间节点的后代
        child1_descendants = self.child1.get_descendants()
        self.assertEqual(len(child1_descendants), 1)
        self.assertIn(self.grandchild, child1_descendants)
        
        # 叶子节点没有后代
        grandchild_descendants = self.grandchild.get_descendants()
        self.assertEqual(len(grandchild_descendants), 0)
    
    def test_get_ancestors(self):
        """测试获取祖先节点"""
        # 构建层级结构
        self.root.add_child(self.child1)
        self.child1.add_child(self.grandchild)
        
        # 根节点没有祖先
        root_ancestors = self.root.get_ancestors()
        self.assertEqual(len(root_ancestors), 0)
        
        # 中间节点有一个祖先
        child1_ancestors = self.child1.get_ancestors()
        self.assertEqual(len(child1_ancestors), 1)
        self.assertIn(self.root, child1_ancestors)
        
        # 叶子节点有两个祖先
        grandchild_ancestors = self.grandchild.get_ancestors()
        self.assertEqual(len(grandchild_ancestors), 2)
        self.assertEqual(grandchild_ancestors[0], self.child1)  # 父节点在前
        self.assertEqual(grandchild_ancestors[1], self.root)   # 根节点在后
    
    def test_get_path(self):
        """测试获取路径"""
        # 构建层级结构
        self.root.add_child(self.child1)
        self.child1.add_child(self.grandchild)
        
        # 获取路径
        path = self.grandchild.get_path()
        expected_path = [self.root, self.child1, self.grandchild]
        self.assertEqual(path, expected_path)
        
        # 根节点路径只包含自己
        root_path = self.root.get_path()
        self.assertEqual(root_path, [self.root])
    
    def test_get_depth(self):
        """测试获取深度"""
        # 构建层级结构
        self.root.add_child(self.child1)
        self.child1.add_child(self.grandchild)
        
        # 验证深度
        self.assertEqual(self.root.get_depth(), 0)
        self.assertEqual(self.child1.get_depth(), 1)
        self.assertEqual(self.grandchild.get_depth(), 2)
    
    def test_is_leaf_and_is_root(self):
        """测试叶子节点和根节点判断"""
        # 初始状态
        self.assertTrue(self.root.is_root())
        self.assertTrue(self.root.is_leaf())
        self.assertFalse(self.child1.is_root())
        self.assertTrue(self.child1.is_leaf())
        
        # 添加子节点后
        self.root.add_child(self.child1)
        self.assertTrue(self.root.is_root())
        self.assertFalse(self.root.is_leaf())  # 有子节点，不再是叶子
        self.assertFalse(self.child1.is_root())
        self.assertTrue(self.child1.is_leaf())
    
    def test_get_subtree_size(self):
        """测试获取子树大小"""
        # 单个节点
        self.assertEqual(self.root.get_subtree_size(), 1)
        
        # 添加子节点
        self.root.add_child(self.child1)
        self.root.add_child(self.child2)
        self.assertEqual(self.root.get_subtree_size(), 3)
        
        # 添加孙子节点
        self.child1.add_child(self.grandchild)
        self.assertEqual(self.root.get_subtree_size(), 4)
        self.assertEqual(self.child1.get_subtree_size(), 2)
        self.assertEqual(self.grandchild.get_subtree_size(), 1)
    
    def test_find_child_by_content(self):
        """测试根据内容查找子节点"""
        self.root.add_child(self.child1)
        self.root.add_child(self.child2)
        
        # 查找存在的子节点
        found = self.root.find_child_by_content("Child 1")
        self.assertEqual(found, self.child1)
        
        # 查找不存在的子节点
        not_found = self.root.find_child_by_content("Nonexistent")
        self.assertIsNone(not_found)
    
    def test_find_descendant_by_id(self):
        """测试根据ID查找后代节点"""
        self.root.add_child(self.child1)
        self.child1.add_child(self.grandchild)
        
        # 查找自己
        found_self = self.root.find_descendant_by_id(self.root.node_id)
        self.assertEqual(found_self, self.root)
        
        # 查找直接子节点
        found_child = self.root.find_descendant_by_id(self.child1.node_id)
        self.assertEqual(found_child, self.child1)
        
        # 查找孙子节点
        found_grandchild = self.root.find_descendant_by_id(self.grandchild.node_id)
        self.assertEqual(found_grandchild, self.grandchild)
        
        # 查找不存在的节点
        not_found = self.root.find_descendant_by_id(99999)
        self.assertIsNone(not_found)
    
    def test_update_content(self):
        """测试更新内容"""
        original_content = self.root.content
        new_content = "Updated Root Node"
        
        self.root.update_content(new_content)
        
        self.assertEqual(self.root.content, new_content)
        self.assertNotEqual(self.root.content, original_content)
        # 更新内容后向量应该被清除
        self.assertIsNone(self.root.vector)
    
    def test_set_vector(self):
        """测试设置词向量"""
        # 创建测试向量
        test_vector = np.array([1.0, 2.0, 3.0], dtype=np.float32)
        
        self.root.set_vector(test_vector)
        
        # 验证向量被正确设置
        self.assertIsNotNone(self.root.vector)
        np.testing.assert_array_equal(self.root.vector, test_vector)
        
        # 验证是副本而不是引用
        test_vector[0] = 999.0
        self.assertNotEqual(self.root.vector[0], 999.0)
        
        # 测试无效向量
        with self.assertRaises(ValueError):
            self.root.set_vector([1, 2, 3])  # 列表而不是numpy数组
    
    def test_get_coordinate_info(self):
        """测试获取坐标信息"""
        coord_info = self.child1.get_coordinate_info()
        
        self.assertIsInstance(coord_info, dict)
        self.assertIn('level_count', coord_info)
        self.assertIn('levels', coord_info)
        self.assertEqual(coord_info['level_count'], 2)
        self.assertEqual(coord_info['levels'], [0, 0])
    
    def test_get_formatted_coordinate(self):
        """测试获取格式化坐标"""
        formatted = self.child1.get_formatted_coordinate()
        self.assertIsInstance(formatted, str)
        self.assertIn("L2:", formatted)
        self.assertIn("0.0", formatted)
    
    def test_to_dict(self):
        """测试转换为字典"""
        # 设置向量和子节点
        test_vector = np.array([1.0, 2.0, 3.0], dtype=np.float32)
        self.root.set_vector(test_vector)
        self.root.add_child(self.child1)
        
        # 基本字典转换
        basic_dict = self.root.to_dict()
        self.assertIn('node_id', basic_dict)
        self.assertIn('content', basic_dict)
        self.assertIn('level', basic_dict)
        self.assertIn('coordinate', basic_dict)
        self.assertIn('is_leaf', basic_dict)
        self.assertIn('is_root', basic_dict)
        self.assertNotIn('vector', basic_dict)
        self.assertNotIn('children', basic_dict)
        
        # 包含向量的字典转换
        dict_with_vector = self.root.to_dict(include_vector=True)
        self.assertIn('vector', dict_with_vector)
        self.assertEqual(len(dict_with_vector['vector']), 3)
        
        # 包含子节点的字典转换
        dict_with_children = self.root.to_dict(include_children=True)
        self.assertIn('children', dict_with_children)
        self.assertEqual(len(dict_with_children['children']), 1)
    
    def test_string_representations(self):
        """测试字符串表示"""
        # __str__ 方法
        str_repr = str(self.root)
        self.assertIn("Node", str_repr)
        self.assertIn("Root Node", str_repr)
        
        # __repr__ 方法
        repr_str = repr(self.root)
        self.assertIn("DocumentNode", repr_str)
        self.assertIn(str(self.root.node_id), repr_str)
    
    def test_equality_and_hash(self):
        """测试相等性和哈希"""
        # 创建相同ID的节点
        same_coord = CoordinateSystem.create_coordinate(1, [0])
        same_node = DocumentNode(same_coord, "Different Content", 0)
        
        # 相同ID的节点应该相等
        self.assertEqual(self.root, same_node)
        self.assertEqual(hash(self.root), hash(same_node))
        
        # 不同ID的节点应该不相等
        self.assertNotEqual(self.root, self.child1)
        self.assertNotEqual(hash(self.root), hash(self.child1))
        
        # 与非DocumentNode对象不相等
        self.assertNotEqual(self.root, "not a node")
        self.assertNotEqual(self.root, 123)


if __name__ == '__main__':
    unittest.main()