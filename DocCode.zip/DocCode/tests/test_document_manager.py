"""
文档管理器单元测试
"""
import unittest
import numpy as np
from unittest.mock import Mock, patch
from src.document_manager import DocumentManager
from src.llm_service import LLMService
from src.coordinate_system import CoordinateSystem


class MockVectorModel:
    """模拟向量模型"""
    def encode(self, text):
        # 基于文本内容生成确定性的向量
        import hashlib
        hash_obj = hashlib.md5(text.encode())
        seed = int(hash_obj.hexdigest()[:8], 16)
        np.random.seed(seed)
        return np.random.rand(384).astype(np.float32)


class MockLLMService:
    """模拟LLM服务"""
    def optimize_structure(self, document):
        return {
            "optimizations": [
                {
                    "type": "reorder",
                    "target_node_id": str(document.root.node_id),
                    "description": "重新排序子节点",
                    "reason": "改善可读性",
                    "priority": "medium"
                }
            ],
            "reasoning": "Mock optimization",
            "priority_order": ["reorder"],
            "expected_benefits": ["更好的结构"]
        }


class TestDocumentManager(unittest.TestCase):
    """测试文档管理器类"""
    
    def setUp(self):
        """设置测试环境"""
        self.vector_model = MockVectorModel()
        self.llm_service = MockLLMService()
        self.doc_manager = DocumentManager(self.vector_model, self.llm_service)
    
    def test_initialization(self):
        """测试初始化"""
        self.assertEqual(len(self.doc_manager.documents), 0)
        self.assertEqual(self.doc_manager.next_doc_id, 1)
        self.assertIsNotNone(self.doc_manager.vector_model)
        self.assertIsNotNone(self.doc_manager.llm_service)
    
    def test_create_document(self):
        """测试创建文档"""
        # 创建基本文档
        title = "Test Document"
        doc_id = self.doc_manager.create_document(title)
        
        self.assertEqual(doc_id, 1)
        self.assertIn(doc_id, self.doc_manager.documents)
        
        document = self.doc_manager.documents[doc_id]
        self.assertEqual(document.title, title)
        self.assertIsNotNone(document.root)
        self.assertEqual(document.node_count, 1)
        
        # 创建带初始内容的文档
        title2 = "Test Document 2"
        initial_content = "Initial content"
        doc_id2 = self.doc_manager.create_document(title2, initial_content)
        
        self.assertEqual(doc_id2, 2)
        document2 = self.doc_manager.documents[doc_id2]
        self.assertEqual(document2.root.content, initial_content)
        
        # 验证下一个文档ID递增
        self.assertEqual(self.doc_manager.next_doc_id, 3)
    
    def test_get_document(self):
        """测试获取文档"""
        # 创建文档
        doc_id = self.doc_manager.create_document("Test")
        
        # 获取存在的文档
        document = self.doc_manager.get_document(doc_id)
        self.assertIsNotNone(document)
        self.assertEqual(document.doc_id, doc_id)
        
        # 获取不存在的文档
        nonexistent = self.doc_manager.get_document(999)
        self.assertIsNone(nonexistent)
    
    def test_delete_document(self):
        """测试删除文档"""
        # 创建文档
        doc_id = self.doc_manager.create_document("Test")
        self.assertIn(doc_id, self.doc_manager.documents)
        
        # 删除存在的文档
        success = self.doc_manager.delete_document(doc_id)
        self.assertTrue(success)
        self.assertNotIn(doc_id, self.doc_manager.documents)
        
        # 删除不存在的文档
        success2 = self.doc_manager.delete_document(999)
        self.assertFalse(success2)
    
    def test_add_node(self):
        """测试添加节点"""
        # 创建文档
        doc_id = self.doc_manager.create_document("Test Document")
        document = self.doc_manager.get_document(doc_id)
        root_coord = document.root.node_id
        
        # 添加第一个子节点
        content1 = "Chapter 1"
        node1_coord = self.doc_manager.add_node(doc_id, root_coord, content1)
        
        self.assertIsNotNone(node1_coord)
        self.assertIn(node1_coord, document.coordinate_map)
        
        node1 = document.get_node(node1_coord)
        self.assertEqual(node1.content, content1)
        self.assertEqual(node1.parent, document.root)
        self.assertIn(node1, document.root.children)
        self.assertEqual(document.node_count, 2)
        
        # 添加第二个子节点
        content2 = "Chapter 2"
        node2_coord = self.doc_manager.add_node(doc_id, root_coord, content2)
        
        self.assertNotEqual(node1_coord, node2_coord)
        self.assertEqual(document.node_count, 3)
        
        # 添加孙子节点
        grandchild_content = "Section 1.1"
        grandchild_coord = self.doc_manager.add_node(doc_id, node1_coord, grandchild_content)
        
        grandchild = document.get_node(grandchild_coord)
        self.assertEqual(grandchild.parent, node1)
        self.assertEqual(document.node_count, 4)
    
    def test_add_node_errors(self):
        """测试添加节点的错误情况"""
        # 文档不存在
        with self.assertRaises(ValueError):
            self.doc_manager.add_node(999, 0, "content")
        
        # 创建文档用于后续测试
        doc_id = self.doc_manager.create_document("Test")
        
        # 父节点不存在
        with self.assertRaises(ValueError):
            self.doc_manager.add_node(doc_id, 999999, "content")
    
    def test_add_node_with_position(self):
        """测试在指定位置添加节点"""
        # 创建文档并添加一些节点
        doc_id = self.doc_manager.create_document("Test")
        document = self.doc_manager.get_document(doc_id)
        root_coord = document.root.node_id
        
        # 添加三个子节点
        node1_coord = self.doc_manager.add_node(doc_id, root_coord, "Node 1")
        node2_coord = self.doc_manager.add_node(doc_id, root_coord, "Node 2")
        node3_coord = self.doc_manager.add_node(doc_id, root_coord, "Node 3")
        
        # 在指定位置插入节点
        insert_coord = self.doc_manager.add_node(doc_id, root_coord, "Inserted Node", position=1)
        
        # 验证节点顺序
        children = document.root.children
        self.assertEqual(len(children), 4)
        self.assertEqual(children[1].content, "Inserted Node")
    
    def test_update_node_content(self):
        """测试更新节点内容"""
        # 创建文档和节点
        doc_id = self.doc_manager.create_document("Test")
        document = self.doc_manager.get_document(doc_id)
        root_coord = document.root.node_id
        
        node_coord = self.doc_manager.add_node(doc_id, root_coord, "Original Content")
        
        # 更新内容
        new_content = "Updated Content"
        success = self.doc_manager.update_node_content(doc_id, node_coord, new_content)
        
        self.assertTrue(success)
        
        node = document.get_node(node_coord)
        self.assertEqual(node.content, new_content)
        
        # 测试无效情况
        success_invalid_doc = self.doc_manager.update_node_content(999, node_coord, "content")
        self.assertFalse(success_invalid_doc)
        
        success_invalid_node = self.doc_manager.update_node_content(doc_id, 999999, "content")
        self.assertFalse(success_invalid_node)
    
    def test_delete_node(self):
        """测试删除节点"""
        # 创建文档和节点
        doc_id = self.doc_manager.create_document("Test")
        document = self.doc_manager.get_document(doc_id)
        root_coord = document.root.node_id
        
        node_coord = self.doc_manager.add_node(doc_id, root_coord, "To Delete")
        initial_count = document.node_count
        
        # 删除节点
        success = self.doc_manager.delete_node(doc_id, node_coord)
        
        self.assertTrue(success)
        self.assertEqual(document.node_count, initial_count - 1)
        self.assertNotIn(node_coord, document.coordinate_map)
        
        # 测试无效情况
        success_invalid_doc = self.doc_manager.delete_node(999, node_coord)
        self.assertFalse(success_invalid_doc)
    
    def test_move_node(self):
        """测试移动节点"""
        # 创建文档和节点结构
        doc_id = self.doc_manager.create_document("Test")
        document = self.doc_manager.get_document(doc_id)
        root_coord = document.root.node_id
        
        # 创建两个主节点和一个子节点
        chapter1_coord = self.doc_manager.add_node(doc_id, root_coord, "Chapter 1")
        chapter2_coord = self.doc_manager.add_node(doc_id, root_coord, "Chapter 2")
        section_coord = self.doc_manager.add_node(doc_id, chapter1_coord, "Section 1.1")
        
        # 移动节点
        success = self.doc_manager.move_node(doc_id, section_coord, chapter2_coord)
        
        self.assertTrue(success)
        
        # 验证移动结果
        section_node = document.get_node(section_coord)
        chapter2_node = document.get_node(chapter2_coord)
        chapter1_node = document.get_node(chapter1_coord)
        
        self.assertEqual(section_node.parent, chapter2_node)
        self.assertIn(section_node, chapter2_node.children)
        self.assertNotIn(section_node, chapter1_node.children)
    
    def test_optimize_document(self):
        """测试文档优化"""
        # 创建文档和一些节点
        doc_id = self.doc_manager.create_document("Test Document")
        document = self.doc_manager.get_document(doc_id)
        root_coord = document.root.node_id
        
        # 添加多个节点以触发优化
        for i in range(5):
            self.doc_manager.add_node(doc_id, root_coord, f"Node {i}")
        
        # 执行优化
        result = self.doc_manager.optimize_document(doc_id)
        
        self.assertIn('success', result)
        self.assertTrue(result['success'])
        self.assertIn('optimizations_applied', result)
        self.assertIn('reasoning', result)
        
        # 测试优化不存在的文档
        result_invalid = self.doc_manager.optimize_document(999)
        self.assertIn('error', result_invalid)
    
    def test_search_documents(self):
        """测试文档搜索"""
        # 创建多个文档
        doc1_id = self.doc_manager.create_document("Python Programming")
        doc2_id = self.doc_manager.create_document("Web Development")
        
        # 添加内容
        doc1 = self.doc_manager.get_document(doc1_id)
        doc2 = self.doc_manager.get_document(doc2_id)
        
        self.doc_manager.add_node(doc1_id, doc1.root.node_id, "Python is a programming language")
        self.doc_manager.add_node(doc1_id, doc1.root.node_id, "Django framework for web")
        self.doc_manager.add_node(doc2_id, doc2.root.node_id, "HTML and CSS basics")
        self.doc_manager.add_node(doc2_id, doc2.root.node_id, "JavaScript programming")
        
        # 搜索所有文档
        results_all = self.doc_manager.search_documents("programming")
        self.assertGreater(len(results_all), 0)
        
        # 搜索特定文档
        results_doc1 = self.doc_manager.search_documents("programming", [doc1_id])
        self.assertGreater(len(results_doc1), 0)
        
        # 验证结果格式
        for result in results_all:
            self.assertIn('doc_id', result)
            self.assertIn('doc_title', result)
            self.assertIn('node_id', result)
            self.assertIn('node_content', result)
            self.assertIn('relevance_score', result)
    
    def test_get_statistics(self):
        """测试获取统计信息"""
        # 初始统计
        initial_stats = self.doc_manager.get_statistics()
        self.assertEqual(initial_stats['total_documents'], 0)
        self.assertEqual(initial_stats['total_nodes'], 0)
        
        # 创建文档和节点
        doc_id = self.doc_manager.create_document("Test Document")
        document = self.doc_manager.get_document(doc_id)
        
        for i in range(3):
            self.doc_manager.add_node(doc_id, document.root.node_id, f"Content {i}")
        
        # 获取更新后的统计
        stats = self.doc_manager.get_statistics()
        self.assertEqual(stats['total_documents'], 1)
        self.assertEqual(stats['total_nodes'], 4)  # 1 root + 3 children
        self.assertGreater(stats['total_content_length'], 0)
        self.assertGreater(stats['average_nodes_per_document'], 0)
    
    def test_vector_encoding(self):
        """测试词向量编码"""
        # 测试正常编码
        text = "This is a test text"
        vector = self.doc_manager._encode_text(text)
        
        self.assertIsInstance(vector, np.ndarray)
        self.assertEqual(vector.dtype, np.float32)
        self.assertEqual(len(vector), 384)
        
        # 测试确定性（相同文本应该产生相同向量）
        vector2 = self.doc_manager._encode_text(text)
        np.testing.assert_array_equal(vector, vector2)
        
        # 测试不同文本产生不同向量
        vector3 = self.doc_manager._encode_text("Different text")
        self.assertFalse(np.array_equal(vector, vector3))
    
    def test_relevance_calculation(self):
        """测试相关性计算"""
        # 精确匹配
        score1 = self.doc_manager._calculate_relevance("python", "Python programming")
        self.assertEqual(score1, 1.0)
        
        # 部分匹配
        score2 = self.doc_manager._calculate_relevance("python programming", "python")
        self.assertEqual(score2, 0.5)  # 1 out of 2 words match
        
        # 无匹配
        score3 = self.doc_manager._calculate_relevance("java", "Python programming")
        self.assertEqual(score3, 0.0)
        
        # 空查询
        score4 = self.doc_manager._calculate_relevance("", "Python programming")
        self.assertEqual(score4, 0.0)
    
    def test_error_handling(self):
        """测试错误处理"""
        # 测试向量编码失败的处理
        class FaultyVectorModel:
            def encode(self, text):
                raise Exception("Encoding failed")
        
        # 创建使用有问题模型的管理器
        faulty_manager = DocumentManager(FaultyVectorModel(), self.llm_service)
        
        # 应该降级到随机向量而不是崩溃
        doc_id = faulty_manager.create_document("Test")
        document = faulty_manager.get_document(doc_id)
        
        self.assertIsNotNone(document.root.vector)
        self.assertEqual(len(document.root.vector), 384)


if __name__ == '__main__':
    unittest.main()