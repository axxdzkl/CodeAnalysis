"""
坐标系统单元测试
"""
import unittest
from src.coordinate_system import CoordinateSystem


class TestCoordinateSystem(unittest.TestCase):
    """测试坐标系统类"""
    
    def test_coordinate_creation_basic(self):
        """测试基本坐标创建"""
        # 测试单层坐标
        coord = CoordinateSystem.create_coordinate(1, [0])
        self.assertIsInstance(coord, int)
        self.assertGreater(coord, 0)
        
        # 测试多层坐标
        coord = CoordinateSystem.create_coordinate(3, [1, 5, 10])
        self.assertIsInstance(coord, int)
        self.assertGreater(coord, 0)
    
    def test_coordinate_creation_with_specific_values(self):
        """测试特定值的坐标创建"""
        # 层级数3，坐标[1, 5, 10]
        coord = CoordinateSystem.create_coordinate(3, [1, 5, 10])
        
        # 验证坐标的位域结构
        # level_count = 3 应该在最高4位
        level_count = (coord >> 60) & 0xF
        self.assertEqual(level_count, 3)
        
        # 第一层 = 1 应该在位置54-59
        level1 = (coord >> 54) & 0x3F
        self.assertEqual(level1, 1)
        
        # 第二层 = 5 应该在位置48-53
        level2 = (coord >> 48) & 0x3F
        self.assertEqual(level2, 5)
        
        # 第三层 = 10 应该在位置42-47
        level3 = (coord >> 42) & 0x3F
        self.assertEqual(level3, 10)
    
    def test_coordinate_parsing(self):
        """测试坐标解析"""
        # 创建坐标
        original_levels = [1, 5, 10]
        coord = CoordinateSystem.create_coordinate(3, original_levels)
        
        # 解析坐标
        parsed = CoordinateSystem.parse_coordinate(coord)
        
        self.assertEqual(parsed['level_count'], 3)
        self.assertEqual(parsed['levels'], original_levels)
    
    def test_coordinate_roundtrip(self):
        """测试坐标创建和解析的往返一致性"""
        test_cases = [
            (1, [0]),
            (1, [63]),  # 最大单层值
            (2, [0, 0]),
            (2, [63, 63]),  # 最大双层值
            (3, [1, 5, 10]),
            (6, [1, 2, 3, 4, 5, 6]),  # 最大层级
        ]
        
        for level_count, levels in test_cases:
            with self.subTest(level_count=level_count, levels=levels):
                # 创建坐标
                coord = CoordinateSystem.create_coordinate(level_count, levels)
                
                # 解析坐标
                parsed = CoordinateSystem.parse_coordinate(coord)
                
                # 验证一致性
                self.assertEqual(parsed['level_count'], level_count)
                self.assertEqual(parsed['levels'], levels)
    
    def test_coordinate_edge_cases(self):
        """测试边界情况"""
        # 最小值
        coord = CoordinateSystem.create_coordinate(1, [0])
        parsed = CoordinateSystem.parse_coordinate(coord)
        self.assertEqual(parsed['level_count'], 1)
        self.assertEqual(parsed['levels'], [0])
        
        # 最大层级数
        coord = CoordinateSystem.create_coordinate(6, [0, 0, 0, 0, 0, 0])
        parsed = CoordinateSystem.parse_coordinate(coord)
        self.assertEqual(parsed['level_count'], 6)
        self.assertEqual(parsed['levels'], [0, 0, 0, 0, 0, 0])
        
        # 最大层级值
        coord = CoordinateSystem.create_coordinate(1, [63])
        parsed = CoordinateSystem.parse_coordinate(coord)
        self.assertEqual(parsed['level_count'], 1)
        self.assertEqual(parsed['levels'], [63])
    
    def test_invalid_coordinate_creation(self):
        """测试无效坐标创建"""
        # 层级数过小
        with self.assertRaises(ValueError):
            CoordinateSystem.create_coordinate(0, [])
        
        # 层级数过大
        with self.assertRaises(ValueError):
            CoordinateSystem.create_coordinate(7, [0, 0, 0, 0, 0, 0, 0])
        
        # 层级数与层级列表长度不匹配
        with self.assertRaises(ValueError):
            CoordinateSystem.create_coordinate(2, [0])
        
        # 层级值过大
        with self.assertRaises(ValueError):
            CoordinateSystem.create_coordinate(1, [64])
        
        # 层级值为负
        with self.assertRaises(ValueError):
            CoordinateSystem.create_coordinate(1, [-1])
    
    def test_get_parent_coordinate(self):
        """测试获取父节点坐标"""
        # 根节点没有父节点
        root_coord = CoordinateSystem.create_coordinate(1, [0])
        parent = CoordinateSystem.get_parent_coordinate(root_coord)
        self.assertIsNone(parent)
        
        # 多层节点的父节点
        child_coord = CoordinateSystem.create_coordinate(3, [1, 5, 10])
        parent_coord = CoordinateSystem.get_parent_coordinate(child_coord)
        
        self.assertIsNotNone(parent_coord)
        
        # 解析父节点坐标
        parent_parsed = CoordinateSystem.parse_coordinate(parent_coord)
        self.assertEqual(parent_parsed['level_count'], 2)
        self.assertEqual(parent_parsed['levels'], [1, 5])
    
    def test_get_next_sibling_coordinate(self):
        """测试获取下一个兄弟节点坐标"""
        # 创建初始坐标
        coord1 = CoordinateSystem.create_coordinate(2, [1, 5])
        
        # 获取下一个兄弟坐标
        coord2 = CoordinateSystem.get_next_sibling_coordinate(coord1)
        
        # 解析兄弟坐标
        parsed = CoordinateSystem.parse_coordinate(coord2)
        self.assertEqual(parsed['level_count'], 2)
        self.assertEqual(parsed['levels'], [1, 6])  # 最后一级应该+1
        
        # 测试根节点没有兄弟节点
        root_coord = CoordinateSystem.create_coordinate(1, [0])
        with self.assertRaises(ValueError):
            CoordinateSystem.get_next_sibling_coordinate(root_coord)
        
        # 测试达到最大索引
        max_coord = CoordinateSystem.create_coordinate(1, [63])
        with self.assertRaises(ValueError):
            CoordinateSystem.get_next_sibling_coordinate(max_coord)
    
    def test_is_ancestor(self):
        """测试祖先关系判断"""
        # 创建祖先和后代坐标
        ancestor = CoordinateSystem.create_coordinate(2, [1, 5])
        descendant = CoordinateSystem.create_coordinate(4, [1, 5, 10, 20])
        
        # 测试祖先关系
        self.assertTrue(CoordinateSystem.is_ancestor(ancestor, descendant))
        self.assertFalse(CoordinateSystem.is_ancestor(descendant, ancestor))
        
        # 测试兄弟关系（不是祖先）
        sibling1 = CoordinateSystem.create_coordinate(3, [1, 5, 10])
        sibling2 = CoordinateSystem.create_coordinate(3, [1, 5, 11])
        self.assertFalse(CoordinateSystem.is_ancestor(sibling1, sibling2))
        self.assertFalse(CoordinateSystem.is_ancestor(sibling2, sibling1))
        
        # 测试同一节点（不是祖先）
        self.assertFalse(CoordinateSystem.is_ancestor(ancestor, ancestor))
    
    def test_format_coordinate(self):
        """测试坐标格式化"""
        # 测试根节点
        root_coord = CoordinateSystem.create_coordinate(1, [0])
        formatted = CoordinateSystem.format_coordinate(root_coord)
        self.assertEqual(formatted, "L1:0")
        
        # 测试多层节点
        coord = CoordinateSystem.create_coordinate(3, [1, 5, 10])
        formatted = CoordinateSystem.format_coordinate(coord)
        self.assertEqual(formatted, "L3:1.5.10")
    
    def test_coordinate_uniqueness(self):
        """测试坐标唯一性"""
        coords = set()
        
        # 生成各种坐标并检查唯一性
        for level_count in range(1, 4):
            for i in range(10):
                levels = [i % 64] * level_count
                coord = CoordinateSystem.create_coordinate(level_count, levels)
                self.assertNotIn(coord, coords, f"Duplicate coordinate for {level_count}, {levels}")
                coords.add(coord)
    
    def test_coordinate_ordering(self):
        """测试坐标排序特性"""
        # 创建一系列坐标
        coords = [
            CoordinateSystem.create_coordinate(1, [0]),
            CoordinateSystem.create_coordinate(1, [1]),
            CoordinateSystem.create_coordinate(2, [0, 0]),
            CoordinateSystem.create_coordinate(2, [0, 1]),
            CoordinateSystem.create_coordinate(2, [1, 0]),
        ]
        
        # 坐标应该按照层级和索引排序
        for i in range(len(coords) - 1):
            self.assertLess(coords[i], coords[i + 1], 
                          f"Coordinate ordering failed at index {i}")


if __name__ == '__main__':
    unittest.main()