"""
GrowDoc 使用示例
演示核心功能的简单脚本
"""
import sys
import json
from pathlib import Path

# 添加src目录到Python路径
sys.path.insert(0, str(Path(__file__).parent / "src"))

import numpy as np
from src.coordinate_system import CoordinateSystem
from src.document_node import DocumentNode
from src.document import Document
from src.llm_service import LLMService
from src.document_manager import DocumentManager
from src.persistence_manager import PersistenceManager


class MockVectorModel:
    """模拟向量模型"""
    def encode(self, text):
        # 基于文本生成确定性向量
        import hashlib
        hash_obj = hashlib.md5(text.encode())
        seed = int(hash_obj.hexdigest()[:8], 16)
        np.random.seed(seed)
        return np.random.rand(384).astype(np.float32)


def demo_coordinate_system():
    """演示坐标系统"""
    print("=" * 50)
    print("坐标系统演示")
    print("=" * 50)
    
    # 创建不同层级的坐标
    root_coord = CoordinateSystem.create_coordinate(1, [0])
    chapter1_coord = CoordinateSystem.create_coordinate(2, [0, 0])
    chapter2_coord = CoordinateSystem.create_coordinate(2, [0, 1])
    section_coord = CoordinateSystem.create_coordinate(3, [0, 0, 0])
    
    print(f"根节点坐标: {CoordinateSystem.format_coordinate(root_coord)}")
    print(f"第一章坐标: {CoordinateSystem.format_coordinate(chapter1_coord)}")
    print(f"第二章坐标: {CoordinateSystem.format_coordinate(chapter2_coord)}")
    print(f"第一节坐标: {CoordinateSystem.format_coordinate(section_coord)}")
    
    # 演示坐标解析
    parsed = CoordinateSystem.parse_coordinate(section_coord)
    print(f"第一节解析: 层级数={parsed['level_count']}, 路径={parsed['levels']}")
    
    # 演示父子关系
    parent = CoordinateSystem.get_parent_coordinate(section_coord)
    print(f"第一节的父节点: {CoordinateSystem.format_coordinate(parent)}")
    
    # 演示兄弟关系
    sibling = CoordinateSystem.get_next_sibling_coordinate(chapter1_coord)
    print(f"第一章的下一个兄弟: {CoordinateSystem.format_coordinate(sibling)}")
    
    print()


def demo_document_structure():
    """演示文档结构"""
    print("=" * 50)
    print("文档结构演示")
    print("=" * 50)
    
    # 创建文档
    doc = Document(1, "Python编程指南")
    
    # 创建根节点
    root_coord = CoordinateSystem.create_coordinate(1, [0])
    root = DocumentNode(root_coord, "Python编程指南", 0)
    doc.set_root(root)
    
    # 添加章节
    chapter1_coord = CoordinateSystem.create_coordinate(2, [0, 0])
    chapter1 = DocumentNode(chapter1_coord, "第一章：基础语法", 1)
    root.add_child(chapter1)
    doc.add_node(chapter1)
    
    chapter2_coord = CoordinateSystem.create_coordinate(2, [0, 1])
    chapter2 = DocumentNode(chapter2_coord, "第二章：数据结构", 1)
    root.add_child(chapter2)
    doc.add_node(chapter2)
    
    # 添加小节
    section1_coord = CoordinateSystem.create_coordinate(3, [0, 0, 0])
    section1 = DocumentNode(section1_coord, "1.1 变量和数据类型", 2)
    chapter1.add_child(section1)
    doc.add_node(section1)
    
    section2_coord = CoordinateSystem.create_coordinate(3, [0, 0, 1])
    section2 = DocumentNode(section2_coord, "1.2 控制流程", 2)
    chapter1.add_child(section2)
    doc.add_node(section2)
    
    # 显示文档结构
    print(f"文档: {doc}")
    print(f"节点总数: {doc.node_count}")
    print(f"最大深度: {doc.get_max_depth()}")
    
    # 显示层级结构
    def print_structure(node, indent=0):
        prefix = "  " * indent
        coord = node.get_formatted_coordinate()
        print(f"{prefix}- [{coord}] {node.content}")
        for child in node.children:
            print_structure(child, indent + 1)
    
    print("\n文档结构:")
    print_structure(root)
    
    # 演示查找功能
    found_node = doc.get_node(section1_coord)
    print(f"\n查找节点 {section1_coord}: {found_node.content}")
    
    # 演示搜索功能
    search_results = doc.search_by_content("数据")
    print(f"\n搜索'数据': 找到 {len(search_results)} 个结果")
    for result in search_results:
        print(f"  - {result.content}")
    
    print()


def demo_document_manager():
    """演示文档管理器"""
    print("=" * 50)
    print("文档管理器演示")
    print("=" * 50)
    
    # 初始化管理器
    vector_model = MockVectorModel()
    llm_service = LLMService()
    manager = DocumentManager(vector_model, llm_service)
    
    # 创建文档
    doc1_id = manager.create_document("Web开发指南", "这是一个Web开发的综合指南")
    doc2_id = manager.create_document("数据库设计", "数据库设计最佳实践")
    
    print(f"创建了文档: {doc1_id}, {doc2_id}")
    
    # 为第一个文档添加内容
    doc1 = manager.get_document(doc1_id)
    root_coord = doc1.root.node_id
    
    # 添加章节
    html_coord = manager.add_node(doc1_id, root_coord, "HTML基础")
    css_coord = manager.add_node(doc1_id, root_coord, "CSS样式")
    js_coord = manager.add_node(doc1_id, root_coord, "JavaScript编程")
    
    # 添加小节
    manager.add_node(doc1_id, html_coord, "HTML标签详解")
    manager.add_node(doc1_id, html_coord, "表单处理")
    manager.add_node(doc1_id, css_coord, "布局技巧")
    
    print(f"文档 {doc1_id} 现在有 {doc1.node_count} 个节点")
    
    # 演示搜索功能
    search_results = manager.search_documents("HTML")
    print(f"\n搜索'HTML': 找到 {len(search_results)} 个结果")
    for result in search_results:
        print(f"  - 文档{result['doc_id']}: {result['node_content']}")
    
    # 演示优化功能
    print(f"\n优化文档 {doc1_id}...")
    optimization_result = manager.optimize_document(doc1_id)
    print(f"优化结果: 应用了 {optimization_result.get('optimizations_applied', 0)} 个优化")
    print(f"原因: {optimization_result.get('reasoning', 'N/A')}")
    
    # 获取统计信息
    stats = manager.get_statistics()
    print(f"\n系统统计:")
    print(f"  总文档数: {stats['total_documents']}")
    print(f"  总节点数: {stats['total_nodes']}")
    print(f"  平均节点/文档: {stats['average_nodes_per_document']:.1f}")
    
    print()


def demo_persistence():
    """演示持久化功能"""
    print("=" * 50)
    print("持久化演示")
    print("=" * 50)
    
    # 初始化组件
    vector_model = MockVectorModel()
    llm_service = LLMService()
    manager = DocumentManager(vector_model, llm_service)
    persistence = PersistenceManager(":memory:")  # 使用内存数据库
    
    # 创建文档
    doc_id = manager.create_document("持久化测试文档")
    doc = manager.get_document(doc_id)
    
    # 添加一些内容
    root_coord = doc.root.node_id
    chapter1_coord = manager.add_node(doc_id, root_coord, "第一章")
    manager.add_node(doc_id, chapter1_coord, "第一节")
    manager.add_node(doc_id, root_coord, "第二章")
    
    print(f"创建文档: {doc.title}, 节点数: {doc.node_count}")
    
    # 保存到数据库
    print("保存到数据库...")
    success = persistence.save_document(doc)
    print(f"保存结果: {'成功' if success else '失败'}")
    
    # 从数据库加载
    print("从数据库加载...")
    loaded_doc = persistence.load_document(doc_id)
    
    if loaded_doc:
        print(f"加载成功: {loaded_doc.title}, 节点数: {loaded_doc.node_count}")
        
        # 验证结构完整性
        validation = loaded_doc.validate_structure()
        print(f"结构验证: {'通过' if validation['valid'] else '失败'}")
        
        if not validation['valid']:
            print(f"问题: {validation['issues']}")
    else:
        print("加载失败")
    
    # 获取数据库统计
    db_stats = persistence.get_database_statistics()
    print(f"\n数据库统计:")
    print(f"  文档数: {db_stats.get('document_count', 0)}")
    print(f"  节点数: {db_stats.get('node_count', 0)}")
    print(f"  平均内容长度: {db_stats.get('average_content_length', 0):.1f}")
    
    print()


def demo_api_example():
    """演示API使用示例"""
    print("=" * 50)
    print("API使用示例")
    print("=" * 50)
    
    api_examples = [
        {
            "action": "创建文档",
            "method": "POST",
            "url": "/documents",
            "data": {"title": "我的文档", "content": "根节点内容"}
        },
        {
            "action": "获取文档",
            "method": "GET", 
            "url": "/documents/1",
            "data": None
        },
        {
            "action": "添加节点",
            "method": "POST",
            "url": "/documents/1/nodes",
            "data": {"parent_coord": 1152921504606846976, "content": "第一章"}
        },
        {
            "action": "搜索内容",
            "method": "GET",
            "url": "/search?q=章节&doc_id=1",
            "data": None
        },
        {
            "action": "优化文档",
            "method": "POST",
            "url": "/documents/1/optimize",
            "data": None
        }
    ]
    
    print("API调用示例:")
    for example in api_examples:
        print(f"\n{example['action']}:")
        print(f"  {example['method']} {example['url']}")
        if example['data']:
            print(f"  数据: {json.dumps(example['data'], ensure_ascii=False, indent=2)}")
    
    print("\nCURL命令示例:")
    print("# 创建文档")
    print('curl -X POST http://localhost:5000/documents \\')
    print('  -H "Content-Type: application/json" \\')
    print('  -d \'{"title":"测试文档","content":"根节点"}\'')
    
    print("\n# 添加节点")
    print('curl -X POST http://localhost:5000/documents/1/nodes \\')
    print('  -H "Content-Type: application/json" \\')
    print('  -d \'{"parent_coord":1152921504606846976,"content":"第一章"}\'')
    
    print()


def main():
    """主演示函数"""
    print("🚀 GrowDoc 核心功能演示")
    print("=" * 60)
    
    try:
        demo_coordinate_system()
        demo_document_structure()
        demo_document_manager()
        demo_persistence()
        demo_api_example()
        
        print("🎉 所有演示完成!")
        print("\n下一步:")
        print("1. 运行 'python api.py' 启动API服务")
        print("2. 运行 'python run_tests.py' 执行测试")
        print("3. 访问 http://localhost:5000/health 验证服务")
        
    except Exception as e:
        print(f"❌ 演示出错: {str(e)}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()